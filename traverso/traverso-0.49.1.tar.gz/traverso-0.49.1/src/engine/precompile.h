#include <qlist.h>
#include <qvariant.h>  // All moc genereated code has this include
#include <qobject.h>
#include <qstring.h>
#include <qstringlist.h>

#include <qapplication.h>
#include <qtimer.h>

#include <stdlib.h>
