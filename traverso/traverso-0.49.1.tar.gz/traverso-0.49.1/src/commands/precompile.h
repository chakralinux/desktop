#include <qlist.h>
#include <qvariant.h>  // All moc genereated code has this include
#include <qobject.h>
#include <qstring.h>
#include <QUndoCommand>
#include <QUndoStack>
#include <qgraphicsview.h>
#include <qwidget.h>
