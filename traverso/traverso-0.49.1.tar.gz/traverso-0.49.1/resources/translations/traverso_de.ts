<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="de">
<context>
    <name>AddRemoveClip</name>
    <message>
        <location filename="../../src/commands/RemoveClip.cpp" line="34"/>
        <source>Remove Clip</source>
        <translation>Clip entfernen</translation>
    </message>
    <message>
        <location filename="../../src/commands/RemoveClip.cpp" line="40"/>
        <source>Remove Selected Clips</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>AlsaDevicesPage</name>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="13"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="19"/>
        <source>ALSA Device</source>
        <translation>ALSA Gerät</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="57"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Device:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The real or virtual ALSA device to be used.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A real device is the audiocard installed in your system.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;A virtual device is one created in the .asoundrc file, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;often located in your home folder.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If unsure, use either the default device, this will use the audiodevice &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;configured by your distribution, or the device that names your audio card.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;In the latter case, please make sure no application uses the audiocard, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;else the driver won&apos;t be able to initialize!&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;For more info see chapter 3.1: &quot;The Driver Backend&quot; of the User Manual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Gerät:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Das echte oder virtuelle benutzte ALSA-Gerät.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Ein echtes Gerät ist eine im System installierte Soundkarte.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Virtuelle Geräte wurden in der Datei .asoundrc definiert, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;welche sich häufig im Benutzerordner befindet.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Im Zweifel können Sie das entweder Standardgerät benutzen - dieses wurde &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Distribution festgelegt - oder Sie wählen einen Namen aus der Liste.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Im letzteren Fall vergewissern Sie sich, dass das Gerät nicht verwendet wird. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Der Treiber könnte dann nicht initialisiert werden!&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Weitere Informationen finden Sie in Kapitel 3.1: &quot;Das Treiber-Backend&quot; des Benutzerhandbuches&lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="76"/>
        <source>Device</source>
        <translation>Gerät</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="105"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Number of Periods:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Audio is managed in small chunks called periods. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This value determines how many of these chunks are &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;to be used by the driver of the audiocard.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The default should work just fine, and gives optimal latency behavior.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;However, some (buggy) alsa drivers don&apos;t work correctly &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;with the default of 2, if you experience very choppy audio, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;please try to use 3 periods.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Zahl der Perioden:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Audio wird in kleinen Abschnitten verwaltet, die Perioden heissen. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Dieser Wert bestimmt, wie viele dieser Abschnitte &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;vom Treiber der Soundkarte verwendet werden&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;In der Regel sind die Standard-Einstellungen optimal in Funktion und Latenz.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Dennoch funktionieren einige ALSA-Treiber nicht richtig&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;mit der Einstellung 2. Wenn Ihr Ton ruckelt, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;versuchen Sie es bitte mit 3 Perioden.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="120"/>
        <source>Nr. of periods</source>
        <translation>Anzahl Perioden</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="128"/>
        <source>2</source>
        <translation>2</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="133"/>
        <source>3</source>
        <translation>3</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="160"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Dither is used to make the audio cleaner. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The best way to describe it is to imagine a painting with many dots. If you view it up close you can see each dot and the image is not very clear. If you view it from far away the image becomes clearer because your eyes/brain dither the dots to smooth out the image. It is a murky subject and obviously a very personal choice as to what dither is the best. For most people it is just plain magic. Anyone running at 16bit who cares about quality or has CPU cycles to spare should run with dither. Triangular is probably the best compromise of quality vs cpu cost (its very fast), but shaped is the best&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;￼p, li { white-space: pre-wrap; }￼&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Dither verbessert die Audioqualität bei Format-Konvertierungen. &lt;/p&gt;￼&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Um die Funktionsweise von Dither zu erklären, stellt man sich am besten ein digitales Bild vor, das aus einzelnen Bildpunkten zusammengesetzt ist. Aus der Nähe sieht das Bild unscharf und unruhig aus. Ab einer bestimmten Entfernung ist das Auge nicht mehr in der Lage, die einzelnen Punkte aufzulösen, das Punktemuster verschwimmt und das eigentliche Bild tritt klarer hervor. Auf Audiosignale bezogen ist Dither ein sehr leises zufälliges Rauschen, das dem digitalen Signal beigemischt wird. Dadurch wird die digitale Rasterung des Signals verwischt und Artefakte, wie sie bei sehr leisen oder stark untersteuerten Passagen auftreten können, werden verringert. Bei hohen Bit-Auflösungen (24, 32-Fliesskomma) ist die Rasterung des Audiosignals so fein, dass Dither kaum eine hörbare Verbesserung bringt. Bei Reduktion auf 16 Bit (z.B. beim Export für eine CD oder beim Abspielen über eine 16-Bit Soundkarte) empfiehlt sich aber auf jeden Fall, Dither zu aktivieren. Welche Art von Dither am angenehmsten klingt, ist eine Frage des Geschmacks. &quot;Triangular&quot; ist ein guter Kompromiss zwischen Qualität und Prozessorbelastung. Sehr gute Qualität bei hoher Prozessorbelastung bietet &quot;shaped&quot;. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="168"/>
        <source>Dither</source>
        <translation>Dither</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="176"/>
        <source>None</source>
        <translation>Kein</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="181"/>
        <source>Shaped</source>
        <translation>Shaped</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="186"/>
        <source>Rectangular</source>
        <translation>Rechteckig (Rectangular)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AlsaDevicesPage.ui" line="191"/>
        <source>Triangular</source>
        <translation>Dreieckig (Triangular)</translation>
    </message>
</context>
<context>
    <name>AlsaDriver</name>
    <message>
        <location filename="../../src/engine/AlsaDriver.cpp" line="187"/>
        <source>ALSA Driver: The playback device %1 is already in use. Please stop the application using it and run Traverso again</source>
        <translation>ALSA Treiber: Das Wiedergabegerät %1 ist bereits in Verwendung. Bitte stoppen Sie das entsprechende Programm und starten Sie Traverso erneut</translation>
    </message>
    <message>
        <location filename="../../src/engine/AlsaDriver.cpp" line="192"/>
        <source>ALSA Driver: You do not have permission to open the audio device %1 for playback</source>
        <translation>ALSA Treiber: Sie haben nicht die Berechtigung, das Audio-Gerät %1 als Wiedergabegerät zu verwenden</translation>
    </message>
    <message>
        <location filename="../../src/engine/AlsaDriver.cpp" line="196"/>
        <source>snd_pcm_open(playback_handle, ..) failed with unknown error type</source>
        <translation>snd_pcm_open(playback_handle, ..) mit einem unbekannten Fehler fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../../src/engine/AlsaDriver.cpp" line="212"/>
        <source>ALSA Driver: The capture device %1 is already in use. Please stop the application using it and run Traverso again</source>
        <translation>ALSA Treiber: Das Aufnahme-Gerät %1 ist bereits in Verwendung. Bitte stoppen Sie das entsprechende Programm und starten Sie Traverso erneut</translation>
    </message>
    <message>
        <location filename="../../src/engine/AlsaDriver.cpp" line="217"/>
        <source>ALSA Driver: You do not have permission to open the audio device %1 for capture</source>
        <translation>ALSA Treiber: Sie haben nicht die Berechtigung, das Audio-Gerät %1 als Aufnahmegerät zu verwenden</translation>
    </message>
    <message>
        <location filename="../../src/engine/AlsaDriver.cpp" line="221"/>
        <source>ALSA Driver: snd_pcm_open(capture_handle, ...) failed with unknown error type</source>
        <translation>snd_pcm_open(playback_handle, ..) mit einem unbekannten Fehler fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../../src/engine/AlsaDriver.cpp" line="237"/>
        <source>ALSA Driver: Cannot open PCM device %1 for playback. Falling back to capture-only mode</source>
        <translation>ALSA Treiber: Kann das PCM Gerät %1 nicht als Wiedergabe-Gerät öffnen. Verwende den Aufnahme-Exklusiv-Modus</translation>
    </message>
    <message>
        <location filename="../../src/engine/AlsaDriver.cpp" line="252"/>
        <source>ALSA: Cannot open PCM device %1 for capture. Falling back to playback-only mode</source>
        <translation>ALSA Treiber: Kann das PCM Gerät %1 nicht als Aufnahme-Gerät öffnen. Verwende den Wiedergabe-Exklusiv-Modus</translation>
    </message>
    <message>
        <location filename="../../src/engine/AlsaDriver.cpp" line="610"/>
        <source>ALSA Driver: Unable to configure hardware, is it in use by another application?</source>
        <translation>ALSA Treiber: Es war nicht möglich, die Hardware zu konfigurieren. Wird sie vielleicht gerade von einer anderen Anwendung benutzt?</translation>
    </message>
</context>
<context>
    <name>AppearenceConfigPage</name>
    <message>
        <location filename="../../src/traverso/dialogs/settings/Pages.cpp" line="444"/>
        <source>Icons only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/Pages.cpp" line="445"/>
        <source>Text only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/Pages.cpp" line="446"/>
        <source>Text beside Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/Pages.cpp" line="447"/>
        <source>Text below Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/Pages.cpp" line="525"/>
        <source>Default Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/Pages.cpp" line="589"/>
        <source>Select default project dir</source>
        <translation>Standard-Projektordner wählen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="23"/>
        <source>Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="35"/>
        <source>Theme selector</source>
        <translation>Motiv wählen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="63"/>
        <source>Path to theme files</source>
        <translation>Pfad zu den Motiv-Dateien</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="140"/>
        <source>Available themes</source>
        <translation>Vorhandene Motive</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="167"/>
        <source>Adjust theme color</source>
        <translation>Motiv-Farbe anpassen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="189"/>
        <source>Theme Options</source>
        <translation>Motiv-Optionen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="201"/>
        <source>Paint audio rectified</source>
        <translation>Audio ausgerichtet zeichnen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="208"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Painting the waveform with an outline is more detailed, but requires more cpu.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you experience slowness when painting many clips, or during animated scroll, unselect this option!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;￼p, li { white-space: pre-wrap; }￼&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Zeichnen der Wellenform mit einer Umrisslinie ist etwas langsamer, aber zeigt mehr Details.&lt;/p&gt;￼&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Deaktivieren Sie diese Option wenn die Darstellung mit vielen Clips oder beim Scrollen langsam wird.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="216"/>
        <source>Paint audio with outline</source>
        <translation>Umrisslinie um Wellenformen zeichnen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="223"/>
        <source>Paint stereo audio as mono audio</source>
        <translation>Stereo-Dateien als einen Kanal zeichnen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="230"/>
        <source>Draw lines at 0 and -6 dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="240"/>
        <source>Style Options</source>
        <translation>Stil-Optionen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="260"/>
        <source>Select style</source>
        <translation>Stil wählen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="279"/>
        <source>Use selected style&apos;s palette</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="309"/>
        <source>Toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="317"/>
        <source>Icon size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="331"/>
        <source>Button style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="345"/>
        <source>Transport Console size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="374"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="380"/>
        <source>Interface Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AppearenceConfigPage.ui" line="393"/>
        <source>Changing the language of the Interface will take
effect after restarting Traverso!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ArmTracks</name>
    <message>
        <location filename="../../src/commands/ArmTracks.cpp" line="39"/>
        <source>Arm Tracks</source>
        <translation>Tracks auf &quot;Aufnahme&quot; schalten</translation>
    </message>
</context>
<context>
    <name>AudioClip</name>
    <message>
        <location filename="../../src/core/AudioClip.cpp" line="575"/>
        <source>Unable to Record to Track</source>
        <translation>Kann nicht auf Track aufnehmen</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.cpp" line="577"/>
        <source>AudioDevice doesn&apos;t have this Capture Bus: %1 (Track %2)</source>
        <translation>Dieser Aufnahmebus existiert nicht: %1 (Track %2)</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.cpp" line="903"/>
        <source>Normalization</source>
        <translation>Normalisieren</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.cpp" line="904"/>
        <source>Set Normalization level:</source>
        <translation>Normalisieren auf Level:</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.cpp" line="653"/>
        <source>Toggle Mute</source>
        <translation>Stummschaltung an/ausschalten</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.h" line="48"/>
        <source>Mute</source>
        <translation>Stummschaltung</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.h" line="52"/>
        <source>Normalize</source>
        <translation>Normalisieren</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.cpp" line="660"/>
        <source>Toggle Lock</source>
        <translation>Sperre an-/ausschalten</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.h" line="53"/>
        <source>Lock</source>
        <translation>Sperre</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.cpp" line="687"/>
        <source>Remove Fades</source>
        <translation>Entferne Ein-/Ausblenden</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.h" line="49"/>
        <source>In: Remove</source>
        <translation>Einblenden: Entfernen</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.h" line="50"/>
        <source>Out: Remove</source>
        <translation>Ausblenden: Entfernen</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.h" line="51"/>
        <source>Both: Remove</source>
        <translation>Beide: Entfernen</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.cpp" line="913"/>
        <source>AudioClip: Normalize</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioClipEditDialog</name>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="30"/>
        <source>Clip Parameters</source>
        <translation>Clip-Einstellungen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="161"/>
        <source>External Processing</source>
        <translation>Externe Bearbeitung</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="122"/>
        <source>hh:mm:ss.sss</source>
        <translation>hh:mm:ss.sss</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="135"/>
        <source>TextLabel</source>
        <translation>TextLabel</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="81"/>
        <source>End</source>
        <translation>Ende</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="313"/>
        <source>Length</source>
        <translation>Länge</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="67"/>
        <source>Track start</source>
        <translation>Track-Anfang</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="60"/>
        <source>Gain</source>
        <translation>Volumen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="53"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="171"/>
        <source>Fades</source>
        <translation>Fades</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="183"/>
        <source>Fade In</source>
        <translation>Fade In</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="303"/>
        <source>Mode</source>
        <translation>Modus</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="296"/>
        <source>Bending</source>
        <translation>Gebogen (Bending)</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="323"/>
        <source>Strength</source>
        <translation>Stärke (Strength)</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="340"/>
        <source>&amp;Linear</source>
        <translation>&amp;Linear</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="347"/>
        <source>&amp;Default</source>
        <translation>&amp;Zurücksetzen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="274"/>
        <source>Fade Out</source>
        <translation>Fade Out</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/ui/AudioClipEditDialog.ui" line="46"/>
        <source>Source</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioClipExternalProcessing</name>
    <message>
        <location filename="../../src/commands/AudioClipExternalProcessing.cpp" line="46"/>
        <source>Clip: External Processing</source>
        <translation>Clip: Externe Verarbeitung</translation>
    </message>
</context>
<context>
    <name>AudioClipManager</name>
    <message>
        <location filename="../../src/core/AudioClipManager.cpp" line="206"/>
        <source>Selection: Add Clip</source>
        <translation>Auswahl: Clip einfügen</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClipManager.cpp" line="203"/>
        <source>Selection: Remove Clip</source>
        <translation>Auswahl: Clip entfernen</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClipManager.cpp" line="213"/>
        <source>Selection: Invert</source>
        <translation>Auswahl: Umkehren</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClipManager.h" line="37"/>
        <source>Select all</source>
        <translation>Alle auswählen</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClipManager.h" line="38"/>
        <source>Invert</source>
        <translation>Umkehren</translation>
    </message>
</context>
<context>
    <name>AudioClipView</name>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.cpp" line="141"/>
        <source>Click to reset AudioFile !</source>
        <translation>Klicken um Audio-Datei zurückzusetzen !</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.cpp" line="992"/>
        <source>Reset Audio File for Clip: %1</source>
        <translation>Audio-Datei zurücksetzen für Clip: %1</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.cpp" line="994"/>
        <source>All files (*);;Audio files (*.wav *.flac)</source>
        <translation>Alle Dateien (*);;Audiodateien (*.wav, *.flac)</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.cpp" line="997"/>
        <source>No file selected!</source>
        <translation>Keine Datei ausgewählt!</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.cpp" line="1013"/>
        <source>Succesfully set AudioClip file to %1</source>
        <translation>AudioClip Datei erfolgreich auf %1 gesetzt</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.h" line="51"/>
        <source>Reset Audio File</source>
        <translation>Audio Datei zurücksetzen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.h" line="52"/>
        <source>Edit Properties</source>
        <translation>Eigenschaften bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.h" line="45"/>
        <source>Closest: Adjust Length</source>
        <translation>Nächstes: Länge ändern</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.h" line="46"/>
        <source>In: Adjust Length</source>
        <translation>Einblenden: Länge anpassen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.h" line="47"/>
        <source>Out: Adjust Length</source>
        <translation>Ausblenden: Länge anpassen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.h" line="48"/>
        <source>In: Select Preset</source>
        <translation>Einblenden: Voreinstellung auswählen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.h" line="49"/>
        <source>Out: Select Preset</source>
        <translation>Ausblenden: Voreinstellung auswählen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/AudioClipView.h" line="50"/>
        <source>Closest: Delete</source>
        <translation>Nächstes: Löschen</translation>
    </message>
</context>
<context>
    <name>AudioDevice</name>
    <message>
        <location filename="../../src/engine/AudioDevice.cpp" line="157"/>
        <source>No Driver Loaded</source>
        <translation>Kein Treiber geladen</translation>
    </message>
    <message>
        <location filename="../../src/engine/AudioDevice.cpp" line="677"/>
        <source>No Device Configured</source>
        <translation>Kein Gerät konfiguriert</translation>
    </message>
    <message>
        <location filename="../../src/engine/AudioDevice.cpp" line="807"/>
        <source>The Jack server has been shutdown!</source>
        <translation>Der Jack Server wurde beendet!</translation>
    </message>
    <message>
        <location filename="../../src/engine/AudioDevice.cpp" line="820"/>
        <source>AudioDevice:: Buffer underrun &apos;Storm&apos; detected, switching to Null Driver</source>
        <translation>AudioDevice: Puffer-Leerlauf in kurzer Folge mehrfach erkannt, wechsele zum Null-Treiber</translation>
    </message>
    <message>
        <location filename="../../src/engine/AudioDevice.cpp" line="821"/>
        <source>AudioDevice:: For trouble shooting this problem, please see Chapter 11 from the user manual!</source>
        <translation>AudioDevice: Um dieses Problem zu beheben, lesen Sie Kapitel 11 im Benutzerhandbuch!</translation>
    </message>
    <message>
        <location filename="../../src/engine/AudioDevice.cpp" line="429"/>
        <source>Audiodevice: Failed to create the Jack Driver</source>
        <translation>Audiogerät: Jack-Treiber konnte nicht erstellt werden</translation>
    </message>
    <message>
        <location filename="../../src/engine/AudioDevice.cpp" line="444"/>
        <source>Audiodevice: Failed to create the ALSA Driver</source>
        <translation>Audiogerät: ALSA-Treiber konnte nicht erstellt werden</translation>
    </message>
    <message>
        <location filename="../../src/engine/AudioDevice.cpp" line="458"/>
        <source>Audiodevice: Failed to create the PortAudio Driver</source>
        <translation>Audiogerät: PortAudio-Treiber konnte nicht erstellt werden</translation>
    </message>
    <message>
        <location filename="../../src/engine/AudioDevice.cpp" line="472"/>
        <source>Audiodevice: Failed to create the PulseAudio Driver</source>
        <translation>Audiogerät: PulseAudio-Treiber konnte nicht erstellt werden</translation>
    </message>
    <message>
        <location filename="../../src/engine/AudioDevice.cpp" line="487"/>
        <source>Audiodevice: Failed to create the CoreAudio Driver</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioDeviceThread</name>
    <message>
        <location filename="../../src/engine/AudioDeviceThread.cpp" line="136"/>
        <source>Unable to set Audiodevice Thread to realtime priority!!!This most likely results in unreliable playback/capture and lots of buffer underruns (== sound drops).In the worst case the program can even malfunction!Please make sure you run this program with realtime privileges!!!</source>
        <translation>Konnte den Audiogeräte-Prozess nicht auf Echtzeit-Priorität setzen! Das wird vermutlich unzuverlässige Aufnahme, Wiedergabe und eine Menge Puffer-Leerläufe (== Aussetzer) verursachen. Schlimmstenfalls kann es Fehlfunktionen im Programm geben! Bitte stellen Sie sicher, dass Sie das Programm mit Echtzeit-Priorität starten!</translation>
    </message>
</context>
<context>
    <name>AudioDriverConfigPage</name>
    <message>
        <location filename="../../src/traverso/dialogs/settings/Pages.cpp" line="210"/>
        <source>System default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="19"/>
        <source>Driver Selection</source>
        <translation>Treiber-Auswahl</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="25"/>
        <source>Driver:</source>
        <translation>Treiber:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="38"/>
        <source>Configure driver</source>
        <translation>Treiber konfigurieren</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="52"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Duplex mode:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Defines if both the Playback and Capture buses &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;of your soundcard are to be used, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;or only the Playback or Capture bus(es).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Duplex Modus:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Definiert ob beide - der Wiedergabe- und Aufnahmebus &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;der Soundkarte - benutzt werden.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;oder nur der Wiedergabe- oder Aufnahmebus &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="61"/>
        <source>Duplex mode</source>
        <translation>Duplex-Modus</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="69"/>
        <source>Full</source>
        <translation>Voll</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="74"/>
        <source>Playback</source>
        <translation>Wiedergabe</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="79"/>
        <source>Capture</source>
        <translation>Aufnahme</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="97"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sample rate:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The sample rate used by the audio card.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;New projects will use this samplerate as &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;the project&apos;s sample rate on creation.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Sample-Frequenz:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Die von der Soundkarte zu benutzende Sample-Frequenz.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Neue Projekte werden diese Sample-Frequenz&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;beim Erstellen als Standard benutzen.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="107"/>
        <source>Sample rate</source>
        <translation>Sample-Frequenz</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="115"/>
        <source>22050</source>
        <translation>22050</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="120"/>
        <source>32000</source>
        <translation>32000</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="125"/>
        <source>44100</source>
        <translation>44100</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="130"/>
        <source>48000</source>
        <translation>48000</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="135"/>
        <source>88200</source>
        <translation>88200</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="140"/>
        <source>96000</source>
        <translation>96000</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="158"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Buffer latency:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The latency introduced by the size of the audio buffers.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Some people need low latencies, if you don&apos;t need it, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;or don&apos;t know what it means, please leave the default setting!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Puffer Latenz:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Die durch die Grösse des Audio-Puffers verursachte Latenz.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Einige Leute brauchen sehr geringe Latenzen. Sollten Sie diese nicht brauchen,&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;oder nicht wissen, was das bedeutet, behalten Sie bitte den Standard bei!&lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="168"/>
        <source>Buffer latency (ms)</source>
        <translation>Puffer Latenz (ms)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="195"/>
        <source>Restart Driver</source>
        <translation>Treiber neu starten</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="207"/>
        <source>Jack</source>
        <translation>Jack</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioDriverConfigPage.ui" line="219"/>
        <source>Enable Jack transport control</source>
        <translation>Jack Transport Control aktivieren</translation>
    </message>
</context>
<context>
    <name>AudioSourcesManagerWidget</name>
    <message>
        <location filename="../../src/traverso/ui/AudioSourcesManagerWidget.ui" line="16"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioSourcesManagerWidget.ui" line="111"/>
        <source>AudioSources</source>
        <translation>Audioquellen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioSourcesManagerWidget.ui" line="75"/>
        <source>Remove sources</source>
        <translation>Quellen löschen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioSourcesManagerWidget.ui" line="87"/>
        <source>Remove source</source>
        <translation>Quelle löschen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioSourcesManagerWidget.ui" line="94"/>
        <source>Remove all sources</source>
        <translation>Alle Quellen löschen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/AudioSourcesManagerWidget.ui" line="101"/>
        <source>Remove unused sources</source>
        <translation>Ungenutzte Quellen löschen</translation>
    </message>
</context>
<context>
    <name>BehaviorConfigPage</name>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="13"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="19"/>
        <source>Project Settings</source>
        <translation>Projekt-Einstellungen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="85"/>
        <source>Load last used project at startup</source>
        <translation>Zuletzt geladenes Projekt beim Programmstart laden</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="69"/>
        <source>Ask</source>
        <translation>Fragen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="76"/>
        <source>Don&apos;t save</source>
        <translation>Nicht speichern</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="95"/>
        <source>New Sheet Settings</source>
        <translation>Einstellungen für neue Arbeitsbereiche</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="162"/>
        <source>Playback Settings</source>
        <translation>Wiedergabe-Einstellungen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="182"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Keep the play cursor in view while playing or recording.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Wiedergabe-Cursor bei der Aufnahme und Wiedergabe im Blickfeld halten.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="188"/>
        <source>Scroll playback</source>
        <translation>Bei Wiedergabe scrollen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="199"/>
        <source>Jump</source>
        <translation>Springen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="204"/>
        <source>Stay Centered</source>
        <translation>Mittig halten</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="209"/>
        <source>Animated</source>
        <translation>Animiert</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="219"/>
        <source>Continuously adjust audio while dragging</source>
        <translation>Änderungen beim Ziehen kontinuierlich anwenden</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="152"/>
        <source>Lock Audio Clips by default</source>
        <translation>Audioclips automatisch sperren</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="140"/>
        <source>Audio Clip Settings</source>
        <translation>Audioclip Einstellungen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="39"/>
        <source>On close:</source>
        <translation>Beim Beenden:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="59"/>
        <source>Save</source>
        <translation>Speichern</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BehaviorConfigPage.ui" line="115"/>
        <source>Number of tracks</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BusSelectorDialog</name>
    <message>
        <location filename="../../src/traverso/ui/BusSelectorDialog.ui" line="13"/>
        <source>Bus Selector</source>
        <translation>Bus Auswahl</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BusSelectorDialog.ui" line="41"/>
        <source>Track</source>
        <translation>Track</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BusSelectorDialog.ui" line="75"/>
        <source>Capture Buses</source>
        <translation>Aufnahme-Busse</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BusSelectorDialog.ui" line="170"/>
        <source>Channels</source>
        <translation>Kanäle</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BusSelectorDialog.ui" line="177"/>
        <source>Both</source>
        <translation>Beide</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BusSelectorDialog.ui" line="187"/>
        <source>Left</source>
        <translation>Links</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BusSelectorDialog.ui" line="194"/>
        <source>Right</source>
        <translation>Rechts</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/BusSelectorDialog.ui" line="147"/>
        <source>Playback Buses</source>
        <translation>Abspielkanäle</translation>
    </message>
</context>
<context>
    <name>CDWritingDialog</name>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="270"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="13"/>
        <source>CD Writing</source>
        <translation>CD brennen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="25"/>
        <source>General Options</source>
        <translation>Allgemeine Einstellungen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="45"/>
        <source>Write current Sheet</source>
        <translation>Brenne den aktuellen Arbeitsbereich</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="55"/>
        <source>Write all Sheets</source>
        <translation>Brenne alle Arbeitsbereiche</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="64"/>
        <source>Calculate and apply normalization</source>
        <translation>Normalisierung berechnen und anwenden</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="71"/>
        <source>Export wav and toc files only (don&apos;t write CD)</source>
        <translation>Exportiere nur das CD-Abbild (CD wird nicht gebrannt)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="81"/>
        <source>Burning Device</source>
        <translation>Brenn-Laufwerk</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="130"/>
        <source>Number of copies</source>
        <translation>Anzahl Kopien</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="157"/>
        <source>Simulate</source>
        <translation>Simulation</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="164"/>
        <source>Speed</source>
        <translation>Geschwindigkeit</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="175"/>
        <source>auto</source>
        <translation>Automatisch</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="180"/>
        <source>1x</source>
        <translation>1x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="185"/>
        <source>2x</source>
        <translation>2x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="190"/>
        <source>4x</source>
        <translation>4x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="195"/>
        <source>8x</source>
        <translation>8x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="200"/>
        <source>12x</source>
        <translation>12x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="205"/>
        <source>16x</source>
        <translation>16x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="210"/>
        <source>20x</source>
        <translation>20x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="215"/>
        <source>24x</source>
        <translation>24x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="220"/>
        <source>28x</source>
        <translation>28x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="225"/>
        <source>32x</source>
        <translation>32x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="230"/>
        <source>36x</source>
        <translation>36x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="235"/>
        <source>40x</source>
        <translation>40x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="240"/>
        <source>44x</source>
        <translation>44x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="245"/>
        <source>48x</source>
        <translation>48x</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="258"/>
        <source>Status</source>
        <translation>Status</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="319"/>
        <source>Start Writing</source>
        <translation>Brennvorgang starten</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="326"/>
        <source>Abort</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/CDWritingDialog.ui" line="333"/>
        <source>Close</source>
        <translation>Schliessen</translation>
    </message>
</context>
<context>
    <name>ClipSelection</name>
    <message>
        <location filename="../../src/commands/ClipSelection.cpp" line="38"/>
        <source>Selection: Remove Clip</source>
        <translation>Auswahl: Clip entfernen</translation>
    </message>
    <message>
        <location filename="../../src/commands/ClipSelection.cpp" line="40"/>
        <source>Selection: Add Clip</source>
        <translation>Auswahl: Clip hinzufügen</translation>
    </message>
    <message>
        <location filename="../../src/commands/ClipSelection.cpp" line="42"/>
        <source>Select Clip</source>
        <translation>Clip auswählen</translation>
    </message>
</context>
<context>
    <name>ClipsViewPort</name>
    <message numerus="yes">
        <location filename="../../src/sheetcanvas/ClipsViewPort.cpp" line="142"/>
        <source>Import %n audiofile(s)</source>
        <translation>
            <numerusform>%n Audiodateien importieren</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
</context>
<context>
    <name>Crop</name>
    <message>
        <location filename="../../src/commands/Crop.cpp" line="54"/>
        <source>AudioClip: Magnetic Cut</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Curve</name>
    <message>
        <location filename="../../src/core/Curve.cpp" line="708"/>
        <source>Add CurveNode</source>
        <translation>Kurvenpunkt hinzufügen</translation>
    </message>
    <message>
        <location filename="../../src/core/Curve.cpp" line="747"/>
        <source>Remove CurveNode</source>
        <translation>Kurvenpunkt entfernen</translation>
    </message>
    <message>
        <location filename="../../src/core/Curve.cpp" line="697"/>
        <source>There is allready a node at this exact position, not adding a new node</source>
        <translation>An dieser Stelle existiert schon ein Knotenpunkt. Füge keinen neuen hinzu.</translation>
    </message>
</context>
<context>
    <name>CurveView</name>
    <message>
        <location filename="../../src/sheetcanvas/CurveView.cpp" line="556"/>
        <source>Drag Node</source>
        <translation>Punkt ziehen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/CurveView.h" line="90"/>
        <source>New node</source>
        <translation>Neuer Punkt</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/CurveView.h" line="91"/>
        <source>Remove node</source>
        <translation>Punkt entfernen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/CurveView.h" line="93"/>
        <source>Move node</source>
        <translation>Punkt verschieben</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/CurveView.cpp" line="654"/>
        <source>Clear Nodes</source>
        <translation>Lösche Knotenpunkte</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/CurveView.h" line="92"/>
        <source>Remove all Nodes</source>
        <translation>Lösche alle Knotenpunkte</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/CurveView.h" line="94"/>
        <source>Move node (vertical only)</source>
        <translation>Knoten verschieben (vertikal)</translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="../../src/traverso/ui/PluginSelector.ui" line="16"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PluginSelector.ui" line="60"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PluginSelector.ui" line="67"/>
        <source>Cancel</source>
        <translation>Abbruch</translation>
    </message>
</context>
<context>
    <name>DigitalClock</name>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="1269"/>
        <source>Digital Clock</source>
        <translation>Digitale Uhr</translation>
    </message>
</context>
<context>
    <name>DragMarker</name>
    <message>
        <location filename="../../src/sheetcanvas/TimeLineView.h" line="38"/>
        <source>Move Left</source>
        <translation>Nach links bewegen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TimeLineView.h" line="39"/>
        <source>Move right</source>
        <translation>Nach rechts bewegen</translation>
    </message>
</context>
<context>
    <name>DragNode</name>
    <message>
        <location filename="../../src/sheetcanvas/CurveView.h" line="39"/>
        <source>Move Up</source>
        <translation>Nach oben bewegen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/CurveView.h" line="40"/>
        <source>Move Down</source>
        <translation>Nach unten bewegen</translation>
    </message>
</context>
<context>
    <name>DriverInfo</name>
    <message>
        <location filename="../../src/traverso/widgets/InfoWidgets.cpp" line="156"/>
        <source>Change Audio Device settings</source>
        <translation>Audio-Geräteeinstellungen ändern</translation>
    </message>
</context>
<context>
    <name>ExportDialog</name>
    <message>
        <location filename="../../src/traverso/ui/ExportDialog.ui" line="19"/>
        <source>Export</source>
        <translation>Export</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportDialog.ui" line="52"/>
        <source>General Options</source>
        <translation>Allgemeine Einstellungen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportDialog.ui" line="90"/>
        <source>Export current Sheet</source>
        <translation>Exportiere den aktuellen Arbeitsbereich</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportDialog.ui" line="100"/>
        <source>Export all Sheets</source>
        <translation>Exportiere alle Arbeitsbereiche</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportDialog.ui" line="139"/>
        <source>Export directory</source>
        <translation>Exportverzeichnis</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportDialog.ui" line="177"/>
        <source>Export status</source>
        <translation>Exportstatus</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportDialog.ui" line="215"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportDialog.ui" line="286"/>
        <source>Abort Export</source>
        <translation>Export abbrechen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportDialog.ui" line="299"/>
        <source>Start Export</source>
        <translation>Export starten</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportDialog.ui" line="306"/>
        <source>Close</source>
        <translation>Schliessen</translation>
    </message>
</context>
<context>
    <name>ExportFormatOptionsWidget</name>
    <message>
        <location filename="../../src/traverso/widgets/ExportFormatOptionsWidget.cpp" line="61"/>
        <source>Best</source>
        <translation>Beste</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/ExportFormatOptionsWidget.cpp" line="62"/>
        <source>High</source>
        <translation>Hoch</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/ExportFormatOptionsWidget.cpp" line="63"/>
        <source>Medium</source>
        <translation>Mittel</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/ExportFormatOptionsWidget.cpp" line="64"/>
        <source>Fast</source>
        <translation>Schnell</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="381"/>
        <source>Bitrate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/ExportFormatOptionsWidget.cpp" line="260"/>
        <source>Average Bitrate</source>
        <translation>Mittlere Bitrate</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="538"/>
        <source>Maximum Bitrate</source>
        <translation>Maximale Bitrate</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="13"/>
        <source>Export Format Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="37"/>
        <source>Format Options</source>
        <translation>Formateinstellungen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="58"/>
        <source>Encoding</source>
        <translation>Kodierung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="113"/>
        <source>File Type</source>
        <translation>Dateityp</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="123"/>
        <source>Channels</source>
        <translation>Kanäle</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="190"/>
        <source>Normalize Audio</source>
        <translation>Audiosignal normalisieren</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="220"/>
        <source>Bitdepth</source>
        <translation>Sampleauflösung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="275"/>
        <source>WavPack options (lossless compression)</source>
        <translation>WavPack-Optionen (verlustfreie Kompression)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="313"/>
        <source>Compression type</source>
        <translation>Kompressionsmethode</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="325"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This option reduces the storage of some floating-point data files by up to about 10% by eliminating some information that has virtually no effect on the audio data. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;While this does technically make the compression lossy, it retains all the advantages of floating point data (&amp;gt;600 dB of dynamic range, no clipping, and 25 bits of resolution). &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This also affects large integer compression by limiting the resolution to 24 bits.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Diese Option reduziert den Speicherverbrauch von Fliesspunkt-Daten um bis zu 10%, indem es Informationen aus dem Audiosignal entfernt, die so gut wie keinen Einfluss auf die Qualität haben.&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Technisch gesehen wird die Kompression dadurch verlustbehaftet, aber die Vorteile der Fliesspunkt-Auflösung bleiben erhalten (&amp;gt;600 dB Dynamikumfang, keine Übersteuerung, 25 Bit Auflösung). &lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Bei Integer-Daten wird die Bit-Auflösung auf maximal 24 Bit reduziert.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="335"/>
        <source>Skip WVX for extra compression (semi-lossless)</source>
        <translation>Überspringe WVX für stärkere Kompression (quasi-verlustfrei)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="351"/>
        <source>Ogg Options</source>
        <translation>Ogg-Optionen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="457"/>
        <source>Quality (Smallest &lt;-&gt; Best)</source>
        <translation>Qualität (kleine Datei &lt;-&gt; gute Qualität)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="522"/>
        <source>Encoding Method</source>
        <translation>Kodiermethode</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="492"/>
        <source>MP3 Options</source>
        <translation>MP3-Optionen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="554"/>
        <source>Minimum Bitrate</source>
        <translation>Minimale Bitrate</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="570"/>
        <source>Quality (Fastest &lt;-&gt; Best)</source>
        <translation>Qualität (schnell &lt;-&gt; gute Qualität)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="708"/>
        <source>Sample Rate</source>
        <translation>Samplefrequenz</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ExportFormatOptionsWidget.ui" line="734"/>
        <source>Conversion quality</source>
        <translation>Qualität der Konvertierung</translation>
    </message>
</context>
<context>
    <name>ExternalProcessingDialog</name>
    <message>
        <location filename="../../src/commands/ExternalProcessingDialog.cpp" line="81"/>
        <source>You have to supply an argument before starting the external process!</source>
        <translation>Sie müssen ein Argument angeben, bevor Sie die externe Bearbeitung starten!</translation>
    </message>
    <message>
        <location filename="../../src/commands/ExternalProcessingDialog.cpp" line="246"/>
        <source>Available arguments for the sox program</source>
        <translation>Für das sox-Programm verfügbare Parameter</translation>
    </message>
    <message>
        <location filename="../../src/commands/ExternalProcessingDialog.cpp" line="256"/>
        <source>Program &lt;b&gt;%1&lt;/b&gt; not installed, or insufficient permissions to run!</source>
        <translation>Das Programm &lt;b&gt;%1&lt;/b&gt; ist nicht installiert oder Ihnen fehlt die zum Ausführen notwendige Berechtigung!</translation>
    </message>
    <message>
        <location filename="../../src/commands/ExternalProcessingDialog.cpp" line="194"/>
        <source>Program &lt;b&gt;%1&lt;/b&gt; crashed!</source>
        <translation>Programm &lt;b&gt;%1&lt;/b&gt; ist abgestürzt!</translation>
    </message>
</context>
<context>
    <name>FadeBend</name>
    <message>
        <location filename="../../src/commands/Fade.cpp" line="161"/>
        <source>Fade In: bend</source>
        <translation>Einblenden: Biegung</translation>
    </message>
    <message>
        <location filename="../../src/commands/Fade.cpp" line="161"/>
        <source>Fade Out: bend</source>
        <translation>Ausblenden: Biegung</translation>
    </message>
</context>
<context>
    <name>FadeCurve</name>
    <message>
        <location filename="../../src/core/FadeCurve.cpp" line="241"/>
        <source>Fade Preset</source>
        <translation>Voreinstellungen für Ein-/Ausblenden</translation>
    </message>
    <message>
        <location filename="../../src/core/FadeCurve.h" line="40"/>
        <source>Toggle Bypass</source>
        <translation>Bypass ein-/ausschalten</translation>
    </message>
    <message>
        <location filename="../../src/core/FadeCurve.h" line="41"/>
        <source>Cycle Shape</source>
        <translation>Form umschalten</translation>
    </message>
    <message>
        <location filename="../../src/core/FadeCurve.h" line="42"/>
        <source>Remove Fade</source>
        <translation>Ein-/Ausblenden entfernen</translation>
    </message>
    <message>
        <location filename="../../src/core/FadeCurve.h" line="43"/>
        <source>Toggle Raster</source>
        <translation>Raster ein-/ausschalten</translation>
    </message>
</context>
<context>
    <name>FadeMode</name>
    <message>
        <location filename="../../src/commands/Fade.cpp" line="339"/>
        <source>Fade In: shape</source>
        <translation>Einblenden: Form</translation>
    </message>
    <message>
        <location filename="../../src/commands/Fade.cpp" line="339"/>
        <source>Fade Out: shape</source>
        <translation>Ausblenden: Form</translation>
    </message>
</context>
<context>
    <name>FadeRange</name>
    <message>
        <location filename="../../src/commands/Fade.cpp" line="51"/>
        <source>Fade In: length</source>
        <translation>Einblenden: Länge</translation>
    </message>
    <message>
        <location filename="../../src/commands/Fade.cpp" line="51"/>
        <source>Fade Out: length</source>
        <translation>Ausblenden: Länge</translation>
    </message>
    <message>
        <location filename="../../src/commands/Fade.cpp" line="63"/>
        <source>Fade In: remove</source>
        <translation>Einblenden: Entfernen</translation>
    </message>
    <message>
        <location filename="../../src/commands/Fade.cpp" line="63"/>
        <source>Fade Out: remove</source>
        <translation>Ausblenden: Entfernen</translation>
    </message>
</context>
<context>
    <name>FadeStrength</name>
    <message>
        <location filename="../../src/commands/Fade.cpp" line="253"/>
        <source>Fade In: strength</source>
        <translation>Einblenden: Stärke</translation>
    </message>
    <message>
        <location filename="../../src/commands/Fade.cpp" line="253"/>
        <source>Fade Out: strength</source>
        <translation>Ausblenden: Stärke</translation>
    </message>
</context>
<context>
    <name>FadeView</name>
    <message>
        <location filename="../../src/sheetcanvas/FadeView.h" line="36"/>
        <source>Adjust Bend</source>
        <translation>Biegung verändern</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/FadeView.h" line="37"/>
        <source>Adjust Strength</source>
        <translation>Stärke verändern</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/FadeView.h" line="38"/>
        <source>Select Preset</source>
        <translation>Voreinstellung auswählen</translation>
    </message>
</context>
<context>
    <name>FileWidget</name>
    <message>
        <location filename="../../src/traverso/widgets/ResourcesWidget.cpp" line="136"/>
        <source>My Computer</source>
        <translation>Mein Computer</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/ResourcesWidget.cpp" line="70"/>
        <source>My Documents</source>
        <translation>Meine Dokumente</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/ResourcesWidget.cpp" line="77"/>
        <source>Parent Directory</source>
        <translation>Nächst höheres Verzeichnis</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/ResourcesWidget.cpp" line="84"/>
        <source>Refresh File View</source>
        <translation>Dateiansicht aktualisieren</translation>
    </message>
</context>
<context>
    <name>Import</name>
    <message>
        <location filename="../../src/commands/Import.cpp" line="99"/>
        <source>Import audio source</source>
        <translation>Audioquelle importieren</translation>
    </message>
    <message>
        <location filename="../../src/commands/Import.cpp" line="62"/>
        <source>Import Audio File</source>
        <translation>Audiodatei importieren</translation>
    </message>
    <message>
        <location filename="../../src/commands/Import.cpp" line="50"/>
        <source>Insert Silence</source>
        <translation>Stille einfügen</translation>
    </message>
    <message>
        <location filename="../../src/commands/Import.cpp" line="93"/>
        <source>Silence</source>
        <translation>Stille</translation>
    </message>
    <message>
        <location filename="../../src/commands/Import.cpp" line="96"/>
        <source>All files (*)</source>
        <translation>Alle Dateien (*)</translation>
    </message>
    <message>
        <location filename="../../src/commands/Import.cpp" line="97"/>
        <source>Audio files (*.wav *.flac *.ogg *.mp3 *.wv *.w64)</source>
        <translation>Audio-Dateien (*.wav *.flac *.ogg *.mp3 *.wv *.w64)</translation>
    </message>
</context>
<context>
    <name>ImportClipsDialog</name>
    <message>
        <location filename="../../src/traverso/ui/ImportClipsDialog.ui" line="13"/>
        <source>Import Audio Clips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ImportClipsDialog.ui" line="21"/>
        <source>Import to Track:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ImportClipsDialog.ui" line="33"/>
        <source>Add Markers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputEngine</name>
    <message>
        <location filename="../../src/core/InputEngine.cpp" line="246"/>
        <source>Modifier key actions are not supported from Context Menu</source>
        <translation>Modifiziertasten-Aktionen sind aus dem Kontextmenü heraus nicht möglich</translation>
    </message>
    <message>
        <location filename="../../src/core/InputEngine.cpp" line="256"/>
        <source>Hold actions are not supported from Context Menu</source>
        <translation>Halte-Aktionen sind aus dem Kontextmenü heraus nicht möglich</translation>
    </message>
    <message>
        <location filename="../../src/core/InputEngine.cpp" line="377"/>
        <source>Command Plugin %1 not found!</source>
        <translation>Command Plugin %1 nicht gefunden!</translation>
    </message>
    <message>
        <location filename="../../src/core/InputEngine.cpp" line="381"/>
        <source>Plugin %1 doesn&apos;t implement Command %2</source>
        <translation>Plugin %1 setzt Befehl %2 nicht um</translation>
    </message>
</context>
<context>
    <name>InsertSilenceDialog</name>
    <message>
        <location filename="../../src/traverso/ui/InsertSilenceDialog.ui" line="13"/>
        <source>Insert Silence</source>
        <translation>Stille einfügen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/InsertSilenceDialog.ui" line="33"/>
        <source>Insert Silence (seconds):</source>
        <translation>Stille einfügen (Sekunden):</translation>
    </message>
</context>
<context>
    <name>Interface</name>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="126"/>
        <source>History</source>
        <translation>Verlauf</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.h" line="75"/>
        <source>About Traverso</source>
        <translation>Über Traverso</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="514"/>
        <source>&amp;Save</source>
        <translation>&amp;Speichern</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="559"/>
        <source>&amp;Quit</source>
        <translation>&amp;Beenden</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="710"/>
        <source>&amp;About Traverso</source>
        <translation>&amp;Alles über Traverso</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="143"/>
        <source>Correlation Meter</source>
        <translation>Korrellationsgrad-Anzeige</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="151"/>
        <source>FFT Spectrum</source>
        <translation>FFT Frequenzspektrum</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="134"/>
        <source>Resources Bin</source>
        <translation>Materialsammlung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="500"/>
        <source>&amp;Project</source>
        <translation>&amp;Projekt</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="502"/>
        <source>&amp;New...</source>
        <translation>&amp;Neu...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="508"/>
        <source>&amp;Open...</source>
        <translation>&amp;Oeffnen...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="523"/>
        <source>&amp;Manage Project...</source>
        <translation>Projekt&amp;manager...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="532"/>
        <source>&amp;Export...</source>
        <translation>&amp;Export...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="653"/>
        <source>&amp;Sheet</source>
        <translation>&amp;Arbeitsbereich</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="660"/>
        <source>New &amp;Track(s)...</source>
        <translation>Neue &amp;Spur(en)...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="656"/>
        <source>New &amp;Sheet(s)...</source>
        <translation>Neuer &amp;Arbeitsbereich...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="584"/>
        <source>Import &amp;Audio...</source>
        <translation>&amp;Audio-Import...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="589"/>
        <source>Insert Si&amp;lence...</source>
        <translation>Sti&amp;lle einfügen...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="618"/>
        <source>&amp;View</source>
        <translation>&amp;Ansicht</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="651"/>
        <source>System Information</source>
        <translation>Systeminformationen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="665"/>
        <source>Se&amp;ttings</source>
        <translation>Eins&amp;tellungen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="698"/>
        <source>&amp;Preferences...</source>
        <translation>&amp;Einstellungen...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="876"/>
        <source>&lt;b&gt;Description&lt;/b&gt;</source>
        <translation>&lt;b&gt;Beschreibung&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="876"/>
        <source>&lt;b&gt;Key Sequence&lt;/b&gt;</source>
        <translation>&lt;b&gt;Tastenfolge&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.h" line="73"/>
        <source>Show Export Dialog</source>
        <translation>Zeige Export-Dialog</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.h" line="74"/>
        <source>Show Context Menu</source>
        <translation>Zeige Kontextmenü</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.h" line="76"/>
        <source>Show Project Management Dialog</source>
        <translation>Zeige Projektverwaltungs-Dialog</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.h" line="77"/>
        <source>Full Screen</source>
        <translation>Vollbild</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.h" line="78"/>
        <source>Export keymap</source>
        <translation>Tastenbelegung exportieren</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="624"/>
        <source>Marker Editor...</source>
        <translation>Markierungseditor...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="372"/>
        <source>Traverso %1 (built with Qt %2)

A multitrack audio recording and editing program.

Look in the Help menu for more info.

Traverso is brought to you by R. Sijrier and others,
including all the people from the Free Software world
who contributed the important technologies on which
Traverso is based (Gcc, Qt, Xorg, Linux, and so on)</source>
        <translation>Traverso %1 (kompiliert gegen Qt %2)

Ein Multi-Track Audio Recording- und Editing-Programm.

Schauen Sie ins Hilfe-Menü für weitere Informationen.

Traverso wird ihnen von R Sijrier und vielen Anderen zur Verfügung
gestellt. Fallen viele Leute aus der Welt der freien Software,
die zu den Technologien beigetragen haben, auf denen 
Traverso basiert. (Gcc, Qt, Xorg, Linux, und so weiter...)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="703"/>
        <source>&amp;Getting Started</source>
        <translation>Der Einstie&amp;g</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="706"/>
        <source>&amp;User Manual</source>
        <translation>Ben&amp;utzerhandbuch</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="1390"/>
        <source>Opening User Manual in external browser!</source>
        <translation>Öffne Benutzerhandbuch in externem Browser!</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="541"/>
        <source>&amp;CD Writing...</source>
        <translation>&amp;CD schreiben...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="549"/>
        <source>&amp;Restore Backup...</source>
        <translation>&amp;Backup wiederherstellen...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="667"/>
        <source>&amp;Recording File Format</source>
        <translation>&amp;Format der Aufnahmedateien</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="1396"/>
        <source>Traverso - Important</source>
        <translation>Traverso - Wichtig</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="1399"/>
        <source>A Project directory changed outside of Traverso. 

This is NOT supported! Please undo this change now!

If you want to rename a Project, use the Project Manager instead!</source>
        <translation>Ein Projekt-Verzeichnis wurde außerhalb von Traverso geändert. 

Dies wird NICHT unterstützt! Bitte machen Sie diese Änderung schnell rückgängig!

Verwenden Sie zum Ändern eines Projektnamens stattdessen bitte den Projekt-Manager!</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="1429"/>
        <source>Traverso - Project load failed</source>
        <translation>Traverso - Laden des Projektes fehlgeschlagen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="1432"/>
        <source>The requested Project `%1` 
could not be loaded for the following reason:

&apos;%2&apos;

You will now be given a list of available backups (if any) 
to restore the Project from.</source>
        <translation>Das Projekt &apos;%1&apos;
konnte nicht geladen werden. Begründung:

&apos;%2&apos;

Falls Backups bestehen, haben Sie nun die Möglichkeit,
ein solches zu öffnen.</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="1463"/>
        <source>Changed encoding for recording to %1</source>
        <translation>Kodierung für Aufnahme in %1 wurde geändert</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="679"/>
        <source>&amp;Resample Quality</source>
        <translation>&amp;Qualität der Samplerate-Konvertierung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="1487"/>
        <source>Changed resample quality to: %1</source>
        <translation>Ändere Qualität der Samplerate-Konvertierung auf: %1</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.h" line="79"/>
        <source>Play</source>
        <translation>Wiedergabe</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.h" line="80"/>
        <source>Record</source>
        <translation>Aufnahme</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="567"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="569"/>
        <source>Undo</source>
        <translation>Rückgängig</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="575"/>
        <source>Redo</source>
        <translation>Wiederholen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="597"/>
        <source>&amp;Snap</source>
        <translation>Einra&amp;sten</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="600"/>
        <source>Snap items to edges of other items while dragging.</source>
        <translation>Objekte beim Ziehen an Kanten anderer Objekte einrasten.</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="604"/>
        <source>S&amp;croll Playback</source>
        <translation>Wiedergabe S&amp;crollen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="607"/>
        <source>Keep play cursor in view while playing or recording.</source>
        <translation>Wiedergabecursor bei Aufnahme/Wiedergabe im Blickfeld halten.</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="611"/>
        <source>&amp;Show Effects</source>
        <translation>Effekte &amp;anzeigen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="614"/>
        <source>Show effect plugins and automation curves on tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="638"/>
        <source>Transport Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="644"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="647"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="680"/>
        <source>Best</source>
        <translation>Beste</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="683"/>
        <source>High</source>
        <translation>Hoch</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="686"/>
        <source>Medium</source>
        <translation>Mittel</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="689"/>
        <source>Fast</source>
        <translation>Schnell</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="702"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="1194"/>
        <source>Open Audio Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="1196"/>
        <source>Audio files (*.wav *.flac *.ogg *.mp3 *.wv *.w64)</source>
        <translation>Audio-Dateien (*.wav *.flac *.ogg *.mp3 *.wv *.w64)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/Interface.cpp" line="1236"/>
        <source>%1: %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JackDriver</name>
    <message>
        <location filename="../../src/engine/JackDriver.cpp" line="110"/>
        <source>Jack Driver: Couldn&apos;t connect to the jack server, is jack running?</source>
        <translation>Jack Treiber: Konnte nicht mit Jack-Server verbinden. Läuft ein Jack Server?</translation>
    </message>
    <message>
        <location filename="../../src/engine/JackDriver.cpp" line="207"/>
        <source>Jack Driver: Connected successfully to the jack server!</source>
        <translation>Jack Treiber: Erfolgreich mit Jack verbunden!</translation>
    </message>
</context>
<context>
    <name>KeyboardConfigPage</name>
    <message>
        <location filename="../../src/traverso/dialogs/settings/Pages.cpp" line="790"/>
        <source>No description set for this keymap</source>
        <translation>Es existiert keine Beschreibung für diese Tastenbelegung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/KeyboardConfigPage.ui" line="13"/>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/KeyboardConfigPage.ui" line="19"/>
        <source>Configure Keyboard</source>
        <translation>Tastatur konfigurieren</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/KeyboardConfigPage.ui" line="33"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Double fact timeout:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The maximum time in miliseconds between 2 key presses &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;to determine if the 2 key presses are a double fact ( &amp;lt;&amp;lt; K &amp;gt;&amp;gt; or &amp;lt;&amp;lt; KK &amp;gt;&amp;gt;)&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; or 2 individual key presses ( a &amp;lt; K &amp;gt; and &amp;lt; K &amp;gt; action, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;or &amp;lt; KK &amp;gt; and &amp;lt; KK &amp;gt; action for example).&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Experienced users can set this value as low as 150 ms, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;if you don&apos;t have much experience yet, please leave the default of 180 ms.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;For more information, see chapter 7: Key Actions. of the User Manual&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Double fact timeout:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Maximale Zeit zwischen 2 Tastendrücken &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;um zu bestimmen, ob diese 2 Tastendrücke ein double fact sind ( &amp;lt;&amp;lt; K &amp;gt;&amp;gt; oder &amp;lt;&amp;lt; KK &amp;gt;&amp;gt;)&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; oder 2 einzelne Tastendrücke ( eine &amp;lt; K &amp;gt; und &amp;lt; K &amp;gt; Aktion, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;oder eine &amp;lt; KK &amp;gt; und &amp;lt; KK &amp;gt; Aktion zum Beispiel).&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Erfahrene Benutzer können hier bis auf 150ms herab gehen, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;weniger Erfahrene sollten es bei 180 ms belassen.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Mehr Informationen finden Sie in Kapitel 7: Tastaturbefehle des Benutzerhandbuches.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/KeyboardConfigPage.ui" line="48"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Bitstream Vera Sans; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Double fact timeout (ms)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Bitstream Vera Sans; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Timeout für Doppelklick-Tastaturbefehle (ms)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/KeyboardConfigPage.ui" line="84"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Hold timeout:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The maximum time to consider a pressed key a hold key fact, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;like [ K ] or [ KK ].&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The shorter this time, the sooner a pressed key will be &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;detected as a hold action. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Experienced users can set this value as low as 110 ms, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;if you don&apos;t have much experience yet, please leave the default of 150 ms.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;For more information, see chapter 7: &quot;Key Actions&quot; of the User Manual.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Timeout für Halten:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Die Zeitgrenze, um einen Tastendruck als Halten zu interpretieren, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;wie [ K ] oder [ KK ].&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Je kürzer diese Zeit ist, um so eher wird ein Tastendruck &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;als Halten-Aktion interpretiert. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Erfahrene Benutzer werden mit 110ms gut zurecht kommen, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;weniger erfahrene sollten es bei eta 150ms belassen.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Weitere Informationen in Kapitel 7: &quot;Tasten-Aktionen&quot; des Benutzerhandbuches.&lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/KeyboardConfigPage.ui" line="100"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Bitstream Vera Sans; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Hold timeout (ms)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;/head&gt;&lt;body style=&quot; white-space: pre-wrap; font-family:Bitstream Vera Sans; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Timeout für Halten (ms)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/KeyboardConfigPage.ui" line="131"/>
        <source>Keymap</source>
        <translation>Tastenbelegung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/KeyboardConfigPage.ui" line="145"/>
        <source>Select keymap</source>
        <translation>Tastenbelegung wählen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/Pages.cpp" line="813"/>
        <source>KeyMap Export</source>
        <translation>Tastenbelegung exportieren</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/Pages.cpp" line="814"/>
        <source>The exported keymap can be found here:

 %1</source>
        <translation>Die exportierte Tastaturbelegung wurde unter
%1
gespeichert.</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/KeyboardConfigPage.ui" line="206"/>
        <source>Export Keymap</source>
        <translation>Tastenbelegung exportieren</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/KeyboardConfigPage.ui" line="213"/>
        <source>Print Keymap</source>
        <translation>Tastaturbelegung drucken</translation>
    </message>
</context>
<context>
    <name>LanguageName</name>
    <message>
        <location filename="../../src/common/Utils.cpp" line="252"/>
        <source>English</source>
        <comment>The name of this Language, e.g. German would be Deutch</comment>
        <translation>Deutch</translation>
    </message>
</context>
<context>
    <name>MarkerDialog</name>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="13"/>
        <source>Markers</source>
        <translation>Markierungen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="32"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="37"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="45"/>
        <source>Options</source>
        <translation>Optionen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="60"/>
        <source>ISRC:</source>
        <translation>ISRC:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="284"/>
        <source>Apply to all</source>
        <translation>Auf alle anwenden</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="287"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="95"/>
        <source>Pre-Emphasis</source>
        <translation>Preemphasis</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="102"/>
        <source>Copy protection</source>
        <translation>Kopierschutz</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="109"/>
        <source>Position: (MM:SS:75ths)</source>
        <translation>Position: (MM:SS:75stel)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="129"/>
        <source>CD-Text</source>
        <translation>CD-Text</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="141"/>
        <source>Title:</source>
        <translation>Titel:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="165"/>
        <source>Performer:</source>
        <translation>Interpret:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="189"/>
        <source>Composer:</source>
        <translation>Komponist:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="214"/>
        <source>CD-Text optional</source>
        <translation>CD-Text optional</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="236"/>
        <source>Arranger:</source>
        <translation>Arrangeur:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="246"/>
        <source>Message:</source>
        <translation>Nachricht:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="310"/>
        <source>&amp;Remove</source>
        <translation>Entfe&amp;rnen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="317"/>
        <source>&amp;Export</source>
        <translation>&amp;Export</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="226"/>
        <source>Songwriter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="337"/>
        <source>&amp;Ok</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/MarkerDialog.ui" line="347"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MoveClip</name>
    <message>
        <location filename="../../src/commands/MoveClip.cpp" line="73"/>
        <source>Copy Clip</source>
        <translation>Clip kopieren</translation>
    </message>
    <message>
        <location filename="../../src/commands/MoveClip.cpp" line="76"/>
        <source>Move Clip</source>
        <translation>Clip verschieben</translation>
    </message>
    <message>
        <location filename="../../src/commands/MoveClip.cpp" line="79"/>
        <source>Move Clip To Start</source>
        <translation>Clip an den Anfang bewegen</translation>
    </message>
    <message>
        <location filename="../../src/commands/MoveClip.cpp" line="82"/>
        <source>Move Clip To End</source>
        <translation>Clip an das Ende verschieben</translation>
    </message>
    <message>
        <location filename="../../src/commands/MoveClip.cpp" line="85"/>
        <source>Fold Sheet</source>
        <translation>Arbeitsbereich falten</translation>
    </message>
    <message>
        <location filename="../../src/commands/MoveClip.cpp" line="88"/>
        <source>Fold Track</source>
        <translation>Spur falten</translation>
    </message>
    <message>
        <location filename="../../src/commands/MoveClip.cpp" line="91"/>
        <source>Fold Markers</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MoveEdge</name>
    <message>
        <location filename="../../src/commands/MoveEdge.cpp" line="38"/>
        <source>Move Clip Edge</source>
        <translation>Clip-Kante verschieben</translation>
    </message>
</context>
<context>
    <name>NewProjectDialog</name>
    <message>
        <location filename="../../src/traverso/dialogs/project/NewProjectDialog.cpp" line="112"/>
        <source>You must supply a name for the project!</source>
        <translation>Es muss ein Projektname angegeben werden!</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/NewProjectDialog.cpp" line="120"/>
        <source>Traverso - Question</source>
        <translation>Traverso - Frage</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/NewProjectDialog.cpp" line="121"/>
        <source>The Project &quot;%1&quot; already exists, do you want to remove it and replace it with a new one ?</source>
        <translation>Ein Projekt namens &quot;%1&quot; existiert bereits. Wollen Sie es löschen und durch ein neues ersetzen?</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/NewProjectDialog.cpp" line="122"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/NewProjectDialog.cpp" line="122"/>
        <source>No</source>
        <translation>Nein</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/NewProjectDialog.cpp" line="168"/>
        <source>Couldn&apos;t create project (%1)</source>
        <translation>Fehler beim Erstellen des Projektes (%1)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="13"/>
        <source>New Project</source>
        <translation>Neues Projekt</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="27"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="50"/>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="79"/>
        <source>Engineer</source>
        <translation>Tontechniker</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="307"/>
        <source>Tracks per Sheet</source>
        <translation>Spuren pro Arbeitsbereich</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="343"/>
        <source>Use Template</source>
        <translation>Vorlage verwenden</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/NewProjectDialog.cpp" line="212"/>
        <source>Open Audio Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/NewProjectDialog.cpp" line="214"/>
        <source>Audio files (*.wav *.flac *.ogg *.mp3 *.wv *.w64)</source>
        <translation>Audio-Dateien (*.wav *.flac *.ogg *.mp3 *.wv *.w64)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="132"/>
        <source>Import Audio Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="224"/>
        <source>Empty Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="174"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="195"/>
        <source>Track Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="200"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="210"/>
        <source>Copy files to project directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewProjectDialog.ui" line="253"/>
        <source>Number of Sheets</source>
        <translation>Anzahl Sheets</translation>
    </message>
</context>
<context>
    <name>NewSheetDialog</name>
    <message>
        <location filename="../../src/traverso/dialogs/project/NewSheetDialog.cpp" line="49"/>
        <source>I can&apos;t create a new Sheet if there is no Project loaded!!</source>
        <translation>Es kann kein neuer Arbeitsbereich erstellt werden wenn kein Projekt geladen wurde!!</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/traverso/dialogs/project/NewSheetDialog.cpp" line="91"/>
        <source>Added %n Sheet(s)</source>
        <translation>
            <numerusform>%n neue Arbeitsbereiche hinzugefügt</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewSheetDialog.ui" line="16"/>
        <source>New Sheet(s)</source>
        <translation>Neue Arbeitsbereiche</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewSheetDialog.ui" line="44"/>
        <source>New Sheet name</source>
        <translation>Name für neuen Arbeitsbereich</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewSheetDialog.ui" line="51"/>
        <source>Sheet count</source>
        <translation>Anzahl Arbeitsbereiche</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewSheetDialog.ui" line="58"/>
        <source>Track count</source>
        <translation>Anzahl Spuren</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewSheetDialog.ui" line="65"/>
        <source>Use Template</source>
        <translation>Vorlage verwenden</translation>
    </message>
</context>
<context>
    <name>NewTrackDialog</name>
    <message>
        <location filename="../../src/traverso/dialogs/project/NewTrackDialog.cpp" line="44"/>
        <source>I can&apos;t create a new Track if there is no Project loaded!!</source>
        <translation>Es kann kein Track hinzugefügt werden, wenn kein Projekt geladen ist!!!</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/traverso/dialogs/project/NewTrackDialog.cpp" line="68"/>
        <source>Added %n Track(s)</source>
        <translation>
            <numerusform>%n Tracks hinzugefügt</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewTrackDialog.ui" line="13"/>
        <source>New Track(s)</source>
        <translation>Neue Tracks</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewTrackDialog.ui" line="33"/>
        <source>Track name</source>
        <translation>Track Name</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/NewTrackDialog.ui" line="53"/>
        <source>Track count</source>
        <translation>Track-Anzahl</translation>
    </message>
</context>
<context>
    <name>OpenProjectDialog</name>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="142"/>
        <source>Description:</source>
        <translation>Beschreibung:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="144"/>
        <source>Created on:</source>
        <translation>Erstellt am:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="170"/>
        <source>No Project selected!</source>
        <translation>Kein Projekt ausgewählt!</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="171"/>
        <source>Select a project and click the &apos;Load&apos; button again</source>
        <translation>Wählen Sie ein Projekt und drücken Sie erneut den Button &apos;Laden&apos;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="216"/>
        <source>Project does not exist! (%1)</source>
        <translation>Das Projekt existiert nicht! (%1)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="210"/>
        <source>You must supply a name for the project!</source>
        <translation>Es muss ein Projektname angegeben werden!</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="221"/>
        <source>Traverso - Question</source>
        <translation>Traverso - Frage</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="222"/>
        <source>Are you sure that you want to remove the project %1 ? It&apos;s not possible to undo it !</source>
        <translation>Wollen sie das Projekt &quot;%1&quot; wirklich entfernen? Diese Aktion kann nicht rückgängig gemacht werden!</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="248"/>
        <source>Choose an existing or create a new Project Directory</source>
        <translation>Wählen sie ein existierendes Projektverzeichnis, oder erstellen Sie ein neues</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="269"/>
        <source>Traverso - Warning</source>
        <translation>Traverso - Warnung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="270"/>
        <source>Unable to create Project directory! 
</source>
        <translation>Konnte Projektordner nicht anlegen! 
</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="270"/>
        <source>Please check permission for this directory: %1</source>
        <translation>Bitte überprüfen Sie die Berechtigungen für das Verzeichnis %1</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="273"/>
        <source>Traverso - Information</source>
        <translation>Traverso - Information</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="273"/>
        <source>Created new Project directory for you here: %1
</source>
        <translation>Ein neues Projektverzeichnis wurde erstellt: %1
</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/OpenProjectDialog.ui" line="13"/>
        <source>Open Project</source>
        <translation>Projekt öffnen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/OpenProjectDialog.ui" line="34"/>
        <source>Selected Project</source>
        <translation>Ausgewähltes Projekt</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/OpenProjectDialog.ui" line="81"/>
        <source>Load</source>
        <translation>Laden</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/OpenProjectDialog.ui" line="98"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/OpenProjectDialog.ui" line="131"/>
        <source>Select Project Dir</source>
        <translation>Projektverzeichnis wählen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="138"/>
        <source>&lt;p&gt;Project directory name &lt;b&gt;%1&lt;/b&gt; is different from the Project title &lt;b&gt;%2&lt;/b&gt;!&lt;/p&gt;&lt;p&gt;Did you rename the Project directory ? &lt;/p&gt;&lt;p&gt;Please rename the directory back to the Project title &lt;b&gt;%1&lt;/b&gt;, and change the Project title with the Project Manager Dialog!&lt;/p&gt;</source>
        <translation>&lt;p&gt;Projekt-Verzeichnis &lt;b&gt;%1&lt;/b&gt; unterscheidet sich vom Projekttitel &lt;b&gt;%2&lt;/b&gt;!&lt;/p&gt;&lt;p&gt;Haben Sie das Projektverzeichnis umbenannt?&lt;/p&gt;&lt;p&gt;Bitte benennen Sie das Projektverzeichnis zurück in den Projektnamen &lt;b&gt;%1&lt;/b&gt; und ändern Sie den Projektnamen im Projekt-Manager-Dialog!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="193"/>
        <source>Project %1 does not exist, did you rename or remove the directory what that name ?</source>
        <translation>Projekt %1 existiert nicht. Haben Sie das dazugehörige Verzeichnis umbenannt oder gelöscht?</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="261"/>
        <source>Please check permission for this directory or choose another one:

 %1</source>
        <translation>Bitte überprüfen Sie die Berechtigungen für dieses Verzeichnis, oder wählen Sie ein anderes:

%1</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/OpenProjectDialog.cpp" line="260"/>
        <source>This directory is not writable by you! 
</source>
        <translation>Dieses Verzeichnis kann nicht geschrieben werden!</translation>
    </message>
</context>
<context>
    <name>PADriver</name>
    <message>
        <location filename="../../src/engine/PADriver.cpp" line="279"/>
        <source>PADriver:: PortAudio error: %1</source>
        <translation>PADriver:: PortAudio Fehler: %1</translation>
    </message>
    <message>
        <location filename="../../src/engine/PADriver.cpp" line="178"/>
        <source>PADriver:: hostapi %1 was not found by Portaudio!</source>
        <translation>PADriver:: hostapi %1 wurde von PortAudio nicht gefunden!</translation>
    </message>
</context>
<context>
    <name>PaDriverPage</name>
    <message>
        <location filename="../../src/traverso/ui/PaDriverPage.ui" line="13"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PaDriverPage.ui" line="25"/>
        <source>Portaudio drivers</source>
        <translation>PortAudio Treiber</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PaDriverPage.ui" line="45"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;PortAudio Driver:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The driver which should drive the PortAudio backend&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;PortAudio supports many driver backends, some of which Traverso has native support for too. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;It is recommended to use Traverso&apos;s native drivers instead of using PortAudio&apos;s, however, if the native drivers give problems, you might try the ones supplied by PortAudio instead!&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;PortAudio provides transparent driver support for multiple platforms, including Windows (see the wmme, direct x and asio options), and Mac OS X (see the CoreAudio and jack options)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;PortAudio Treiber:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Der Treiber für das PortAudio Backend&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;PortAudio unterstützt viele Treiber-Backends von denen Traverso einige auch selbst unterstützt. &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Es wird empfohlen, wenn möglich die Traverso-eigenen Treiber zu benutzen. Solle es Probleme geben, ist ein Versuch mit PortAudio jedoch eine gute Idee.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;PortAudio bietet transparente Unterstützung für verschiedene Platformen. Unter anderem Windows (beachten Sie wmme, DirectX und asio Optionen) und Mac OS X (beachten Sie CoreAudio and jack Optionen)&lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PaDriverPage.ui" line="57"/>
        <source>Driver</source>
        <translation>Treiber</translation>
    </message>
</context>
<context>
    <name>PerformanceConfigPage</name>
    <message>
        <location filename="../../src/traverso/ui/PerformanceConfigPage.ui" line="13"/>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PerformanceConfigPage.ui" line="160"/>
        <source>Painting</source>
        <translation>Zeichnen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PerformanceConfigPage.ui" line="198"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The number of times per second at which the Graphical&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Items are repainted during a jog action, like moving an&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;AudioClip, or changing the Gain.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The default frames per second of 35 is a perfect compromise &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;between smooth painting, and low cpu usage.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;However, if you find the painting to be not smooth enough,&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;change this value to a higher one, but keep in mind that it&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;will consume considerably more cpu!&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If for example moving an AudioClip still takes to much cpu,&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;you should consider to lower this value.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Legt fest, wie oft bei einer Jog-Aktion die Elemente neu&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;gezeichnet werden. Beispiele waeren das Bewegen eines&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Audio-Clip oder eine Gain-Änderung.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Standard ist hier 35. Dies ist ein guter Kompromiss zwischen&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;einer angenehmen Ansicht und vertretbarer Last.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Sollte die Anzeige dennoch nicht fluessig genug sein,&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;erhöhen Sie den Wert. Behalten Sie allerdings im Hinterkopf,&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;dass dies ihre CPU spürbar mehr beansprucht!&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Andersherum kann ein senken des Wertes sinnvoll sein,&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;wenn es z.B. Leistungsprobleme beim verschieben eines Clips gibt.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PerformanceConfigPage.ui" line="216"/>
        <source>Jog repaint speed (fps)</source>
        <translation>Jog Neuzeichnungsrate (fps)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PerformanceConfigPage.ui" line="244"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Accelerates the painting of AudioClips and Tracks by using&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;the 3D engine of your graphics card.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Depending on your graphics card and driver support, this &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;can speed up painting considerably!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Beschleunigt die Anzeige von Clips und Tracks durch&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;die im System vorhandende Grafikhardware.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Abhängig von der Karte und den Treibern kann dies die Anzeige &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;auf grandiose Weise beschleunigen!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PerformanceConfigPage.ui" line="254"/>
        <source>Use hardware acceleration</source>
        <translation>Hardwarebeschleunigung verwenden</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PerformanceConfigPage.ui" line="19"/>
        <source>Audio file buffering</source>
        <translation>Audio-Datei puffern</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PerformanceConfigPage.ui" line="57"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Read buffer size:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The amount of audio data that can be stored in the &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;read buffers in seconds.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The default value of 1 second should do just fine.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;However, if you&apos;re tight on memory, you can make this value lower.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If you experience buffer underruns when the hard disk bandwidth is &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;(almost) saturated, or when buffer underruns happen regularly due &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;the hard disk can&apos;t keep up for some reason, you can try a larger &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;value, like 1.5 or 2.0 seconds.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Keep in mind that when using a larger buffer, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;it will take considerably more time to move (i.e. seeking) &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;the playhead to another positions, since all the buffers &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;(one for each audioclip * channel count) need to be refilled!&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }&lt;/style&gt;&lt;/head&gt;
&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Größe des Lese-Puffers:&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Die Menge an Audio-Daten, die in den Lese-Puffern&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;gespeichert werden kann (in Sekunden)&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Der Standard von einer Sekunde sollte gut funktionieren.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Wenn es allerdings an Speicher mangelt, kann der Wert reduziert werden.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Gibt es einen Puffer-Leerlauf, so ist die Bandbreite der Festplatte(n) &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;nahezu ausgelastet. Bei regelmäßigem Auftreten aufgrund &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;zu geringen Festplattendurchsatzes, versuchen Sie einen Wert von&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;1.5 oder 2 Sekunden&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Behalten Sie im Hinterkopf, dass ein grosser Puffer, &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;spürbar Längere Verzögerungen beim verschieben &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;des Wiedergabekopfes verursacht, da alle Puffer &lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;(einer pro Clip in jedem Kanal) neu gefüllt werden müssen!&lt;/p&gt;
&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PerformanceConfigPage.ui" line="77"/>
        <source>Read buffer size (seconds)</source>
        <translation>Lesepuffer-Größe (Sekunden)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PerformanceConfigPage.ui" line="134"/>
        <source>info icon</source>
        <translation>Info Icon</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PerformanceConfigPage.ui" line="147"/>
        <source>Changing the buffer size only will take 
into effect after (re)loading a project.</source>
        <translation>Eine Änderung der Puffer-Größe wird erst 
nach (Neu)laden des Projektes angewandt.</translation>
    </message>
</context>
<context>
    <name>PluginSelectorDialog</name>
    <message>
        <location filename="../../src/traverso/ui/PluginSelectorDialog.ui" line="72"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PluginSelectorDialog.ui" line="79"/>
        <source>Cancel</source>
        <translation>Abbruch</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PluginSelectorDialog.ui" line="13"/>
        <source>Plugin Selector</source>
        <translation>Plugin Auswahl</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PluginSelectorDialog.ui" line="25"/>
        <source>Add Plugin too</source>
        <translation>Plugin hinzufügen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PluginSelectorDialog.ui" line="33"/>
        <source>Plugin Name</source>
        <translation>Plugin Name</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PluginSelectorDialog.ui" line="38"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/PluginSelectorDialog.ui" line="43"/>
        <source>In/Out</source>
        <translation>Ein-/Ausgang</translation>
    </message>
</context>
<context>
    <name>PluginView</name>
    <message>
        <location filename="../../src/sheetcanvas/PluginView.h" line="40"/>
        <source>Remove</source>
        <translation>Entfernen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/PluginView.h" line="39"/>
        <source>Edit...</source>
        <translation>Bearbeiten...</translation>
    </message>
</context>
<context>
    <name>ProgressToolBar</name>
    <message>
        <location filename="../../src/traverso/widgets/InfoWidgets.cpp" line="577"/>
        <source>Importing file %1 of %2: %p%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/InfoWidgets.cpp" line="534"/>
        <source>Progress Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Project</name>
    <message>
        <location filename="../../src/core/Project.cpp" line="154"/>
        <source>Cannot create dir %1</source>
        <translation>Konnte Verzeichnis %1 nicht erstellen</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="132"/>
        <source>Created new Project %1</source>
        <translation>Neues Projekt %1 erstellt</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="206"/>
        <source>Project File Version does not match, unable to load Project!</source>
        <translation>Die Version der Projektdatei passt nicht. Kann das Projekt nicht laden!</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="256"/>
        <source>Project %1 loaded</source>
        <translation>Projekt %1 geladen</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="284"/>
        <source>Project %1 saved </source>
        <translation>Projekt %1 gespeichert </translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="446"/>
        <source>Sheet %1 added</source>
        <translation>Sheet %1 hinzugefügt</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="472"/>
        <source>Sheet &apos;%1&apos; doesn&apos;t exist!</source>
        <translation>Sheet &apos;%1&apos; existiert nicht!</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="519"/>
        <source>Remove Sheet %1</source>
        <translation>Sheet &apos;%1&apos; entfernen</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="605"/>
        <source>Detected clipping in exported audio! (%1)</source>
        <translation>Es wurde Clipping im exportierten Audiosignal erkannt! (%1)</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="609"/>
        <source>calculated norm factor: %1</source>
        <translation>Errechneter Normalisierungsfaktor: %1</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="892"/>
        <source>Traverso - Information</source>
        <translation>Traverso - Information</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="893"/>
        <source>You&apos;re still recording, please stop recording first to be able to exit the application!</source>
        <translation>Es läuft noch eine Aufnahme. Bitte beenden Sie diese, bevor Sie das Programm verlassen!</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="536"/>
        <source>Export already in progress, cannot start it twice!</source>
        <translation>Export wurde bereits gestartet!</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="352"/>
        <source>Project with title &apos;%1&apos; allready exists, not setting new title!</source>
        <translation>Es gibt bereits ein Projekt mit dem Titel &apos;%1&apos;. Der neue Titel wurde nicht gesetzt!</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="362"/>
        <source>Project directory %1 no longer exists, did you rename it? Shame on you! Please undo that, and come back later to rename your Project...</source>
        <translation>Projekt-Verzeichnis &apos;%1&apos; existiert nicht mehr. Haben Sie es umbenannt? Böööse! Bitte machen Sie diese Änderung rückgängig und fahren erst danach mit diesem Projekt fort...</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="376"/>
        <source>Project title changed, Project will to be reloaded to ensure proper operation</source>
        <translation>Da sich der Projekt-Titel geändert hat, wird das Projekt nun neu geladen um ein anständiges Arbeiten möglich zu machen</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="178"/>
        <source>Project %1: Cannot open project.tpf file! (Reason: %2)</source>
        <translation>Projekt %1: Datei project.tpf kann nicht geöffnet werden! (Grund: %2)</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="196"/>
        <source>Project %1: Failed to parse project.tpf file! (Reason: %2)</source>
        <translation>Projekt %1: Konnte project.tpf nicht parsen! (%2)</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="274"/>
        <source>Couldn&apos;t open Project properties file for writing! (File %1. Reason: %2)</source>
        <translation>Konnte die Datei für die Projekteinstellungen nicht zum Schreiben öffnen (Datei %1. Grund: %2)</translation>
    </message>
    <message>
        <location filename="../../src/core/Project.cpp" line="543"/>
        <source>Unable to create export directory! Please check permissions for this directory: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectConverter</name>
    <message>
        <location filename="../../src/core/ProjectConverter.cpp" line="50"/>
        <source>Project file with version %1 cannot be converted, only files with version 2 can!</source>
        <translation>Projektdateien mit Version %1 können nicht konvertiert werden. Konvertierung ist nur mit Dateien von Version 2 möglich!</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectConverter.cpp" line="87"/>
        <source>Project %1: Failed to parse project.tpf file! (Reason: %2)</source>
        <translation>Projekt %1: Konnte project.tpf nicht parsen! (%2)</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectConverter.cpp" line="103"/>
        <source>Starting to convert Project from version 2 to version 3</source>
        <translation>Beginne das Projekt von Version 2 zu Version 3 zu konvertieren</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectConverter.cpp" line="268"/>
        <source>Converting project.tpf file..... Done!</source>
        <translation>Konvertierung von project.tpf..... Beendet!</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectConverter.cpp" line="273"/>
        <source>&lt;b&gt;Need to convert %1 files&lt;/b&gt;</source>
        <translation>&lt;b&gt;%1 Dateien zu konvertieren&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectConverter.cpp" line="290"/>
        <source>Couldn&apos;t open Project properties file for writing! (File %1. Reason: %2)</source>
        <translation>Konnte die Datei für die Projekteinstellungen nicht zum Schreiben öffnen (Datei %1. Grund: %2)</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectConverter.cpp" line="296"/>
        <source>Project %1 converted</source>
        <translation>Projekt %1 wurde konvertiert</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectConverter.cpp" line="297"/>
        <source>Saving converted project.tpf file.... Done!</source>
        <translation>Konvertierte Datei project.tpf wird gespeichert.... Beendet!</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectConverter.cpp" line="304"/>
        <source>Conversion finished succesfully</source>
        <translation>Konvertierung erfolgreich beendet</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectConverter.cpp" line="316"/>
        <source>No conversion description available!</source>
        <translation>Keine Beschreibung der Konvertierung verfügbar!</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectConverter.cpp" line="365"/>
        <source>Conversion stopped on user request, you can continue to use this Project with Traverso &lt;= 0.41.0, or reopen it with this version of Traverso and start the conversion again</source>
        <translation>Konvertierung durch Benutzer abgebrochen. Die Datei kann weiterhin mit Traverso &lt;= 0.41.0 geöffnet werden, oder neu mit dieser Version von Traverso konvertiert werden</translation>
    </message>
</context>
<context>
    <name>ProjectConverterDialog</name>
    <message>
        <location filename="../../src/traverso/ui/ProjectConverterDialog.ui" line="13"/>
        <source>Project Converter</source>
        <translation>Projektkonvertierung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectConverterDialog.ui" line="25"/>
        <source>Project XXX (no translation needed)</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectConverterDialog.ui" line="44"/>
        <source>Conversion information</source>
        <translation>Informationen zur Konvertierung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectConverterDialog.ui" line="63"/>
        <source>Conversion progress</source>
        <translation>Fortschritt der Konvertierung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectConverterDialog.ui" line="101"/>
        <source>Start conversion</source>
        <translation>Beginne Konvertierung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectConverterDialog.ui" line="108"/>
        <source>Stop conversion</source>
        <translation>Beende Konvertierung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectConverterDialog.ui" line="115"/>
        <source>Load Project</source>
        <translation>Projekt laden</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectConverterDialog.ui" line="122"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
</context>
<context>
    <name>ProjectInfoWidget</name>
    <message>
        <location filename="../../src/traverso/ui/ProjectInfoWidget.ui" line="16"/>
        <source>Project Information Widget</source>
        <translation>Projektinformationen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectInfoWidget.ui" line="60"/>
        <source>Bitdepth</source>
        <translation>Sampleauflösung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectInfoWidget.ui" line="183"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectInfoWidget.ui" line="135"/>
        <source>Rate</source>
        <translation>Samplefrequenz</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectInfoWidget.ui" line="231"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectInfoWidget.ui" line="201"/>
        <source>Songs</source>
        <translation>Songs</translation>
    </message>
</context>
<context>
    <name>ProjectManager</name>
    <message>
        <location filename="../../src/core/ProjectManager.h" line="42"/>
        <source>Save Project</source>
        <translation>Projekt speichern</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="112"/>
        <source>Do you want to save the Project before quiting?</source>
        <translation>Wollen Sie das Projekt vor dem Beenden speichern?</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="169"/>
        <source>Project %1 already exists!</source>
        <translation>Projekt %1 existiert bereits!</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="180"/>
        <source>Unable to create new Project %1</source>
        <translation>Konnte neues Projekt %1 nicht erstellen</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="224"/>
        <source>Unable to load Project %1</source>
        <translation>Konnte Projekt %1 nicht laden</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="286"/>
        <source>No Project to save, open or create a Project first!</source>
        <translation>Es gibt nichts zu speichern. Öffnen oder erstellen Sie zuerst ein Projekt!</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="328"/>
        <source>Using existing Project directory: %1
</source>
        <translation>Verwende ein existierendes Projektverzeichnis: %1
</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="330"/>
        <source>Traverso - Warning</source>
        <translation>Traverso - Warnung</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="332"/>
        <source>Unable to create Project directory! 
</source>
        <translation>Konnte Projektorder nicht anlegen! 
</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="332"/>
        <source>Please check permission for this directory: %1</source>
        <translation>Bitte überprüfen Sie die Berechtigungen für Verzeichnis %1</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="335"/>
        <source>Created new Project directory for you here: %1
</source>
        <translation>Ein neues Projektverzeichnis wurde erstellt: %1
</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="359"/>
        <source>Default Project created by Traverso</source>
        <translation>Standardprojekt erstellt von Traverso</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.h" line="43"/>
        <source>Exit application</source>
        <translation>Programm verlassen</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="355"/>
        <source>Project %1 no longer could be found! (Did you remove or rename the Project directory ?)</source>
        <translation>Projekt %1 konnte nicht mehr gefunden werden! (Haben Sie das Projektverzeichnis umbenannt oder verschoben?)</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="453"/>
        <source>Could not rename Project directory to %1</source>
        <translation>Konnte Projektverzeichnis nicht zu %1 umbenennen</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="322"/>
        <source>This directory is not writable by you! 
</source>
        <translation>Dieses Verzeichnis kann nicht geschrieben werden!</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="323"/>
        <source>Please check permission for this directory or choose another one:

 %1</source>
        <translation>Bitte überprüfen Sie die Berechtigungen auf dieses Verzeichnis oder wählen Sie ein anderes:

%1</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="539"/>
        <source>Projectfile backup: The project file %1 could not be opened for reading (Reason: %2)</source>
        <translation>Projekt-Backup: Projektdatei %1 konnte nicht gelesen werden (Grund: %2)</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="693"/>
        <source>Cannot create dir %1</source>
        <translation>Konnte Verzeichnis %1 nicht erstellen</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="308"/>
        <source>Choose a directory to store your Projects in</source>
        <translation>Wählen Sie ein Verzeichnis für ihre Projekte</translation>
    </message>
    <message>
        <location filename="../../src/core/ProjectManager.cpp" line="314"/>
        <source>No directory was selected, to retry open the &apos;Open Project Dialog&apos; and click &apos;Select Project Directory&apos; button
</source>
        <translation>Es wurde kein Verzeichnis ausgewählt. Im Dialog &quot;Projekt öffnen&quot;, &quot;Projektverzeichnis auswählen&quot; kann es nachträglich ausgewählt werden</translation>
    </message>
</context>
<context>
    <name>ProjectManagerDialog</name>
    <message>
        <location filename="../../src/traverso/dialogs/project/ProjectManagerDialog.cpp" line="173"/>
        <source>No new Sheet name was supplied!</source>
        <translation>Es wurde kein Name für den neuen Arbeitsbereich angegeben!</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/ProjectManagerDialog.cpp" line="236"/>
        <source>Save Template</source>
        <translation>Vorlage speichern</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/ProjectManagerDialog.cpp" line="237"/>
        <source>Enter Template name</source>
        <translation>Geben Sie den Namen der Vorlage ein</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/ProjectManagerDialog.cpp" line="248"/>
        <source>Unable to create directory %1!</source>
        <translation>Konnte Verzeichnis %1 nicht anlegen!</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/ProjectManagerDialog.cpp" line="295"/>
        <source>Traverso - Information</source>
        <translation>Traverso - Information</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/ProjectManagerDialog.cpp" line="260"/>
        <source>Template with name %1 already exists!
 Do you want to overwrite it?</source>
        <translation>Eine Vorlage mit dem Namen %1 existiert bereits!
Wollen Sie diese überschreiben?</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/ProjectManagerDialog.cpp" line="276"/>
        <source>Saved Project Template: %1</source>
        <translation>Projektvorlage gespeichert: %1</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/ProjectManagerDialog.cpp" line="278"/>
        <source>Couldn&apos;t open file %1 for writing!</source>
        <translation>Konnte Datei %1 nicht zum Schreiben öffnen!</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetManagerDialog.ui" line="19"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetManagerDialog.ui" line="35"/>
        <source>Project</source>
        <translation>Projekt</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="47"/>
        <source>Informational</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="73"/>
        <source>Title</source>
        <translation>Titel</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="106"/>
        <source>Description</source>
        <translation>Beschreibung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="139"/>
        <source>Engineer</source>
        <translation>Tontechniker</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="160"/>
        <source>Export</source>
        <translation>Export</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="172"/>
        <source>Sheet(s)</source>
        <translation>Arbeitsbereich(e)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="179"/>
        <source>Template</source>
        <translation>Vorlage</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetManagerDialog.ui" line="40"/>
        <source>Sheets</source>
        <translation>Arbeitsbereiche</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetManagerDialog.ui" line="78"/>
        <source>Selected Sheet</source>
        <translation>Ausgewählter Arbeitsbereich</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetManagerDialog.ui" line="108"/>
        <source>Delete</source>
        <translation>Löschen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetManagerDialog.ui" line="134"/>
        <source>Rename</source>
        <translation>Umbenennen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetManagerDialog.ui" line="146"/>
        <source>New Sheet</source>
        <translation>Neuer Arbeitsbereich</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetManagerDialog.ui" line="166"/>
        <source>Create new Sheet</source>
        <translation>Neuen Arbeitsbereich erstellen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="674"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Undo last change&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Letzte Änderung Rückgängig machen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="693"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Redo last change&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Letzte Änderung wiederholen&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetManagerDialog.ui" line="219"/>
        <source>undotext</source>
        <translation>Rückgängig</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetManagerDialog.ui" line="232"/>
        <source>redotext</source>
        <translation>Wiederholen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="246"/>
        <source>Sheet Name</source>
        <translation>Name des Arbeitsbereiches</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="251"/>
        <source>Tracks</source>
        <translation>Spuren</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="256"/>
        <source>Length</source>
        <translation>Länge</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="388"/>
        <source>CD Text</source>
        <translation>CD-Text</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="406"/>
        <source>Performer</source>
        <translation>Interpret</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="422"/>
        <source>Disc ID:</source>
        <translation>Disc ID:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="438"/>
        <source>UPC EAN:</source>
        <translation>UPC EAN:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="454"/>
        <source>Genre:</source>
        <translation>Genre:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="462"/>
        <source>Unused</source>
        <translation>Unused</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="467"/>
        <source>Undefined</source>
        <translation>Undefined</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="472"/>
        <source>Adult Contemporary</source>
        <translation>Adult Contemporary</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="477"/>
        <source>Alternative Rock</source>
        <translation>Alternative Rock</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="482"/>
        <source>Childrens</source>
        <translation>Childrens</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="487"/>
        <source>Classical</source>
        <translation>Classical</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="492"/>
        <source>Contemporary Christian</source>
        <translation>Contemporary Christian</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="497"/>
        <source>Country</source>
        <translation>Country</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="502"/>
        <source>Dance</source>
        <translation>Dance</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="507"/>
        <source>Easy Listening</source>
        <translation>Easy Listening</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="512"/>
        <source>Erotic</source>
        <translation>Erotic</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="517"/>
        <source>Folk</source>
        <translation>Folk</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="522"/>
        <source>Gospel</source>
        <translation>Gospel</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="527"/>
        <source>Hip Hop</source>
        <translation>Hip Hop</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="532"/>
        <source>Jazz</source>
        <translation>Jazz</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="537"/>
        <source>Latin</source>
        <translation>Latin</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="542"/>
        <source>Musical</source>
        <translation>Musical</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="547"/>
        <source>New Age</source>
        <translation>New Age</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="552"/>
        <source>Opera</source>
        <translation>Opera</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="557"/>
        <source>Operette</source>
        <translation>Operette</translation>
    </message>
    <message encoding="UTF-8">
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="562"/>
        <source>Pop Music</source>
        <translation>Pop Music</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="567"/>
        <source>Rap</source>
        <translation>Rap</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="572"/>
        <source>Reggae</source>
        <translation>Reggae</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="577"/>
        <source>Rock Music</source>
        <translation>Rock Music</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="582"/>
        <source>Rhythm and Blues</source>
        <translation>Rhytm and Blues</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="587"/>
        <source>Sound Effects</source>
        <translation>Sound Effects</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="592"/>
        <source>Spoken Word</source>
        <translation>Spoken Word</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="597"/>
        <source>World Music</source>
        <translation>World Music</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="618"/>
        <source>Arranger</source>
        <translation>Arrangeur</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="638"/>
        <source>Message</source>
        <translation>Mitteilung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/project/ProjectManagerDialog.cpp" line="296"/>
        <source>Project with title &apos;%1&apos; allready exists, please supply a different title!</source>
        <translation>Ein Projekt mit dem Titel &apos;%1&apos; existiert bereits. Bitte geben Sie einen anderen Titel an!</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ProjectManagerDialog.ui" line="628"/>
        <source>Songwriter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="194"/>
        <source>No error occurred</source>
        <translation>Keine Fehler aufgetreten</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="195"/>
        <source>An error occurred when reading from the file.</source>
        <translation>Beim Lesen der Datei ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="196"/>
        <source>An error occurred when writing to the file.</source>
        <translation>Beim Schreiben der Datei ist ein Fehler aufgetreten.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="197"/>
        <source>A fatal error occurred.</source>
        <translation>Ein schwerer Fehler ist aufgetreten.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="198"/>
        <source>The file could not be opened.</source>
        <translation>Die Datei konnte nicht geöffnet werden.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="199"/>
        <source>Resourc error</source>
        <translation>Resourcenfehler</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="200"/>
        <source>The operation was aborted.</source>
        <translation>Die Operation wurde abgebrochen.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="201"/>
        <source>A timeout occurred.</source>
        <translation>Zeitüberschreitung.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="202"/>
        <source>An unspecified error occurred.</source>
        <translation>Ein unbekannter Fehler ist aufgetreten.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="203"/>
        <source>The file could not be removed.</source>
        <translation>Die Datei konnte nicht gelöscht werden.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="204"/>
        <source>The file could not be renamed.</source>
        <translation>Die Datei konnte nicht umbenannt werden.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="205"/>
        <source>The position in the file could not be changed.</source>
        <translation>Die Position in der Datei konnte nicht geändert werden.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="206"/>
        <source>The file could not be resized.</source>
        <translation>Die Größe der Datei konnte nicht geändert werden.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="207"/>
        <source>The file could not be accessed.</source>
        <translation>Zugriff auf die Datei nicht möglich.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="208"/>
        <source>The file could not be copied.</source>
        <translation>Die Datei konnte nicht kopiert werden.</translation>
    </message>
    <message>
        <location filename="../../src/core/FileHelpers.cpp" line="209"/>
        <source>Unknown error</source>
        <translation>Unbekannte Fehler</translation>
    </message>
    <message>
        <location filename="../../src/core/AudioClip.cpp" line="123"/>
        <source>AudioClip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/Curve.cpp" line="128"/>
        <source>Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/Curve.cpp" line="129"/>
        <source>CurveNode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/FadeCurve.cpp" line="84"/>
        <source>FadeCurve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/Marker.cpp" line="35"/>
        <source>Marker</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.cpp" line="148"/>
        <source>Sheet</source>
        <translation type="unfinished">Sheet</translation>
    </message>
    <message>
        <location filename="../../src/core/TimeLine.cpp" line="39"/>
        <source>TimeLine</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/core/Track.cpp" line="78"/>
        <source>Track</source>
        <translation type="unfinished">Track</translation>
    </message>
</context>
<context>
    <name>QuickStartDialog</name>
    <message>
        <location filename="../../src/traverso/ui/QuickStart.ui" line="13"/>
        <source>Traverso: Getting Started</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/QuickStart.ui" line="31"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;Traverso: Getting Started&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;When you record or import an audio file into Traverso, it shows up as an Audio Clip in one of the horizontal Tracks in the current Sheet.  You can edit many aspects of these Clips by placing the mouse pointer over a Clip and pressing or holding different keys on your keyboard and mouse.  You can also change settings of a Track, the Sheet as a whole, and other objects in the Sheet.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;To see a list of what commands are available for any given object in the Sheet, move the mouse over that object, and Right-Click (or press Q).  The keyboard shortcuts for each command are shown in the menu.  The notation used is shown below.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; K &amp;gt;  &lt;/span&gt; means press and release the K key. (Like a click.)&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt;&amp;lt; K &amp;gt;&amp;gt;&lt;/span&gt; means press the K key two times fast. (Like a double click.)&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;    &lt;span style=&quot; font-weight:600;&quot;&gt;[ K ]&lt;/span&gt;    means drag the mouse while holding down the K key.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;  &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; KL &amp;gt; &lt;/span&gt; means press the K and L keys at the same time.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;[ KL ]  &lt;/span&gt; means drag the mouse while holding down the K and L keys at the same time.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Here are some basic commands:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; SPACE &amp;gt;&lt;/span&gt; is Play/Stop.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; SHIFT &amp;gt;&lt;/span&gt;  sets the Playhead. (Blue vertical line where playing starts.)&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;       &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; W &amp;gt;&lt;/span&gt;    sets the Work Cursor. (Red vertical line.)&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;       &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; V &amp;gt;    &lt;/span&gt; moves the Playhead back to the Work Cursor.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;        &lt;span style=&quot; font-weight:600;&quot;&gt;[ D ] &lt;/span&gt;     move objects around (Audio Clip, Curve Nodes, etc)&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;        &lt;span style=&quot; font-weight:600;&quot;&gt;[ Z ]&lt;/span&gt;       zooms in and out.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;        &lt;span style=&quot; font-weight:600;&quot;&gt;[ TAB ]&lt;/span&gt;<byte value="x9"/> scroll omnidirectional (aka Shuttle) &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;And some Audio Clip Commands:&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;[ E ] &lt;/span&gt;  drags a Clip&apos;s left or right edge.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;[ F ]&lt;/span&gt;   adjusts the length of a Clip&apos;s Fade In / Fade Out.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;[ G ]   &lt;/span&gt;addust the Gain of a clip (also works on Tracks, Sheet)&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;  &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; X &amp;gt;&lt;/span&gt;  splits the Clip at the cursor&apos;s position.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;For more information, right-click on everything, or check out the Traverso manual.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;￼p, li { white-space: pre-wrap; }￼&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;span style=&quot; font-size:18pt; font-weight:600;&quot;&gt;Traverso: Erste Schritte&lt;/span&gt;&lt;/p&gt;￼&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Eine aufgenommene oder importierte Audiodatei wird in einer der horizontalen Spuren des aktuellen Arbeitsbereiches angezeigt. Zahlreiche Funktionen können über Tasten ausgewählt werden, solange sich der Mauszeiger über der Audiodatei befindet. Funktionen von Spuren können ebenfalls über Tasten gewählt werden, wenn sich der Mauszeiger über einem leeren Bereich der Spur befindet.&lt;/p&gt;￼&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Eine Liste aller verfügbarer Funktionen kann über die rechte Maustaste oder die Taste Q geöffnet werden. Folgende Notation wird für die verschiedenen Arten von Tastaturbefehlen verwendet:&lt;/p&gt;￼&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; K &amp;gt;  &lt;/span&gt; drücke die K-Taste und lasse sie wieder los&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt;&amp;lt; K &amp;gt;&amp;gt;&lt;/span&gt; drücke die K-Taste zweimal nacheinander wie ein Doppelklick&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;    &lt;span style=&quot; font-weight:600;&quot;&gt;[ K ]&lt;/span&gt;  drücke die K-Taste und halte sie gedrückt. Bewege die Maus während K gedrückt ist&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;  &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; KL &amp;gt; &lt;/span&gt; drücke K und L einmal gleichzeitig&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;[ KL ]  &lt;/span&gt; halte K und L gleichzeitig gedrückt und bewege die Maus&lt;/p&gt;￼&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Einige der wichtigesten Funktionen:&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; SPACE &amp;gt;&lt;/span&gt; Wiedergabe starten/stoppen.&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; SHIFT &amp;gt;&lt;/span&gt;  positioniere die Abspielposition. (Senkrechte blaue Linie, die die aktuelle Abspielposition markiert.)&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;       &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; W &amp;gt;&lt;/span&gt;  positioniert den Arbeits-Cursor (rote senkrechte Linie)&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;       &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; V &amp;gt;    &lt;/span&gt; setzt die Abspielposition auf den Arbeits-Cursor&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;        &lt;span style=&quot; font-weight:600;&quot;&gt;[ D ] &lt;/span&gt;   Verschieben von Objekten&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;        &lt;span style=&quot; font-weight:600;&quot;&gt;[ Z ]&lt;/span&gt; Vergrössern / Verkleinern&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;        &lt;span style=&quot; font-weight:600;&quot;&gt;[ TAB ]&lt;/span&gt;￼ Sichtbaren Bereich verschieben (Scrollen) &lt;/p&gt;￼&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Einige Befehle für Audio-Clips:&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;[ E ] &lt;/span&gt;  Linkes oder rechtes Ende verschieben&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;[ F ]&lt;/span&gt;   Länge von Ein-/Ausblendung verändern.&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;   &lt;span style=&quot; font-weight:600;&quot;&gt;[ G ] &lt;/span&gt; Lautstärke ändern&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;  &lt;span style=&quot; font-weight:600;&quot;&gt;&amp;lt; X &amp;gt;&lt;/span&gt;  Clip in zwei Hälften teilen&lt;/p&gt;￼&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;￼&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;Weiter Informationen sind im Handbuch zu finden.&lt;/p&gt;￼&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;￼&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;￼&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>ReadSource</name>
    <message>
        <location filename="../../src/core/ReadSource.cpp" line="107"/>
        <source>Silence</source>
        <translation>Stille</translation>
    </message>
    <message>
        <location filename="../../src/core/ReadSource.cpp" line="703"/>
        <source>Could not open file</source>
        <translation>Die Datei konnte nicht geöffnet werden.</translation>
    </message>
    <message>
        <location filename="../../src/core/ReadSource.cpp" line="704"/>
        <source>Invalid channel count</source>
        <translation>Ungültige Anzahl Spuren</translation>
    </message>
    <message>
        <location filename="../../src/core/ReadSource.cpp" line="705"/>
        <source>File has zero channels</source>
        <translation>Die Datei enthält keine Spuren</translation>
    </message>
    <message>
        <location filename="../../src/core/ReadSource.cpp" line="706"/>
        <source>The file does not exist!</source>
        <translation>Datei existiert nicht!</translation>
    </message>
    <message>
        <location filename="../../src/core/ReadSource.cpp" line="709"/>
        <source>No ReadSource error set</source>
        <translation>No ReadSource-Fehler</translation>
    </message>
</context>
<context>
    <name>RecordingConfigPage</name>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="19"/>
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="25"/>
        <source>Recording</source>
        <translation>Aufnahme</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="45"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;WAV&lt;/span&gt; : A format without compression. Uses more hard disk space then compressed encoding formats, but needs very little cpu.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Limits : ~ 1.7 hours of recording time @ Stereo - 44.1 KHz&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;WavPack&lt;/span&gt; : A format with compression, up to 2 times smaller compared to WAV, and no quality loss. Uses significantly more cpu then WAV, but with modern (year 2005 and above) cpu&apos;s this shouldn&apos;t be a problem.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Using this format stresses the hard disk much less, increasing hard disk live, and less chance of saturating the hard disk bandwidth.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Limits : ~ 5 hours recording time @ Stereo - 44.1 KHz&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;WAV64&lt;/span&gt; : WAV format with 64 bit header, support by other programs is currently limited.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Limits : None, thousands of hours of recording time, supposed that your hard disk can hold it.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;WAV&lt;/span&gt; : Ein unkomprimiertes Format. Benötigt mehr Festplattenplatz als komprimierte Formate, belastet aber den Prozessor weniger.&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Einschränkungen: Aufnahmezeit auf ca 1.7 Stunden limitiert bei 44.1 KHz in Stereo.&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;WavPack&lt;/span&gt; : Ein verlustfrei komprimiertes Format, das die Dateigrösse gegenüber WAV auf etwa die Hälfte reduziert. Verursacht deutlich mehr Prozessorbelastung, was aber mit modernen Computern kein Problem sein sollte.&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Ein komprimiertes Format reduziert die Zugriffe auf die Festplatte, und erlaubt daher das gleichzeitige Lesen von mehr Kanälen.&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Einschränkungen: Maximale Aufnahmezeit bei 44.1 kHz in Stereo ca. 5 Stunden.&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;WAV64&lt;/span&gt; : WAV-Format mit 64 bit Header (von anderen Programmen zum Teil noch nicht unterstützt!)&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Einschränkungen: Keine, nahezu unlimitierte Aufnahmezeit.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="65"/>
        <source>Encoding format</source>
        <translation>Kodierformat</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="90"/>
        <source>WavPack options</source>
        <translation>WavPack-Optionen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="110"/>
        <source>Compression type</source>
        <translation>Kompressionsmethode</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="122"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This option reduces the storage of some floating-point data files by up to about 10% by eliminating some information that has virtually no effect on the audio data. &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;While this does technically make the compression lossy, it retains all the advantages of floating point data (&amp;gt;600 dB of dynamic range, no clipping, and 25 bits of resolution). &lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This also affects large integer compression by limiting the resolution to 24 bits.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;p, li { white-space: pre-wrap; }&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Diese Option reduziert den Speicherverbrauch von Fliesspunkt-Daten um bis zu 10%, indem es Informationen aus dem Audiosignal entfernt, die so gut wie keinen Einfluss auf die Qualität haben.&lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Technisch gesehen wird die Kompression dadurch verlustbehaftet, aber die Vorteile der Fliesspunkt-Auflösung bleiben erhalten (&amp;gt;600 dB Dynamikumfang, keine Übersteuerung, 25 Bit Auflösung). &lt;/p&gt;&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Bei Integer-Daten wird die Bit-Auflösung auf maximal 24 Bit reduziert.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="132"/>
        <source>Skip WVX for extra compression (semi-lossless)</source>
        <translation>Überspringe WVX für stärkere Kompression (quasi-verlustfrei)</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="145"/>
        <source>Resampling</source>
        <translation>Samplerate-Konvertierung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="180"/>
        <source>On the fly resample quality</source>
        <translation>Qualität der Samplerate-Konvertierung in Echtzeit</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="187"/>
        <source>Default export resample quality</source>
        <translation>Qualität der Samplerate-Konvertierung beim Export</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="229"/>
        <source>Best</source>
        <translation>Beste</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="234"/>
        <source>High</source>
        <translation>Hoch</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="239"/>
        <source>Medium</source>
        <translation>Mittel</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="244"/>
        <source>Fast</source>
        <translation>Schnell</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RecordingConfigPage.ui" line="157"/>
        <source>Enable on the fly resampling (Playback only)</source>
        <translation>Echtzeit-Resampling aktivieren (nur bei Wiedergabe)</translation>
    </message>
</context>
<context>
    <name>ResourcesManager</name>
    <message>
        <location filename="../../src/core/ResourcesManager.cpp" line="235"/>
        <source>ResourcesManager::  Failed to initialize ReadSource %1 (Reason: %2)</source>
        <translation>ResourcesManager:: Konnte Readsource %1 nicht initialisieren (Grund: %2)</translation>
    </message>
    <message>
        <location filename="../../src/core/ResourcesManager.cpp" line="427"/>
        <source>ResourcesManager: Received request to remove Audio Source %1but it is still in use by %2 AudioClips!!. NOT removing it!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ResourcesWidget</name>
    <message>
        <location filename="../../src/traverso/ui/ResourcesWidget.ui" line="13"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ResourcesWidget.ui" line="42"/>
        <source>Sources</source>
        <translation>Quellen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ResourcesWidget.ui" line="47"/>
        <source>Files</source>
        <translation>Dateien</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ResourcesWidget.ui" line="106"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ResourcesWidget.ui" line="111"/>
        <source>Length</source>
        <translation>Länge</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ResourcesWidget.ui" line="116"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/ResourcesWidget.ui" line="121"/>
        <source>End</source>
        <translation>Ende</translation>
    </message>
</context>
<context>
    <name>RestoreProjectBackupDialog</name>
    <message>
        <location filename="../../src/traverso/ui/RestoreProjectBackupDialog.ui" line="13"/>
        <source>Restore from backup </source>
        <translation>Backup wiederherstellen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RestoreProjectBackupDialog.ui" line="19"/>
        <source>Set the date to restore the selected backup.</source>
        <translation>Geben Sie das Datum der gewünschten Sicherheitskopie ein.</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RestoreProjectBackupDialog.ui" line="30"/>
        <source>Current date and time:</source>
        <translation>Aktuelles Datum und Zeit:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RestoreProjectBackupDialog.ui" line="37"/>
        <source>Last backup:</source>
        <translation>Letzte Sicherheitskopie:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RestoreProjectBackupDialog.ui" line="55"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RestoreProjectBackupDialog.ui" line="67"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/RestoreProjectBackupDialog.ui" line="72"/>
        <source>Time</source>
        <translation>Zeit</translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../../src/traverso/dialogs/settings/SettingsDialog.cpp" line="103"/>
        <source>Behavior</source>
        <translation>Verhalten</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/SettingsDialog.cpp" line="109"/>
        <source>Appearance</source>
        <translation>Erscheinung</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/SettingsDialog.cpp" line="130"/>
        <source>Keyboard</source>
        <translation>Tastatur</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/SettingsDialog.cpp" line="137"/>
        <source>Performance</source>
        <translation>Leistungsverhalten</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/SettingsDialog.cpp" line="123"/>
        <source>Audio Options</source>
        <translation>Audiooptionen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/SettingsDialog.cpp" line="116"/>
        <source>Sound System</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/dialogs/settings/SettingsDialog.cpp" line="83"/>
        <source>Preferences - Traverso</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Sheet</name>
    <message>
        <location filename="../../src/core/Sheet.cpp" line="1090"/>
        <source>Hard Disk overload detected!</source>
        <translation>Festplattenüberlastung erkannt!</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.cpp" line="1082"/>
        <source>Failed to fill ReadBuffer in time</source>
        <translation>Konnte Lesepuffer nicht rechtzeitig füllen</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.cpp" line="1091"/>
        <source>Failed to empty WriteBuffer in time</source>
        <translation>Konnte Schreibpuffer nicht rechtzeitig leeren</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.cpp" line="347"/>
        <source>Add Track</source>
        <translation>Spur hinzufügen</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.cpp" line="356"/>
        <source>Remove Track</source>
        <translation>Spur entfernen</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.cpp" line="95"/>
        <source>Untitled</source>
        <translation>Unbenannt</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.cpp" line="97"/>
        <source>No artists name set</source>
        <translation>Kein Künstlername festgelegt</translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/core/Sheet.cpp" line="1370"/>
        <source>Recording to %n Clip(s)</source>
        <translation>
            <numerusform>Aufnahme in %n Clips</numerusform>
            <numerusform></numerusform>
        </translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="55"/>
        <source>Play</source>
        <translation>Wiedergabe</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="56"/>
        <source>Record</source>
        <translation>Aufnahme</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="57"/>
        <source>Workcursor: To next edge</source>
        <translation>Arbeitscursor: Zu nächster Kante</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="58"/>
        <source>Workcursor: To previous edge</source>
        <translation>Arbeitscursor: Zu vorheriger Kante</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="59"/>
        <source>Undo</source>
        <translation>Rückgängig</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="60"/>
        <source>Redo</source>
        <translation>Wiederholen</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="61"/>
        <source>Snap: On/Off</source>
        <translation>Einrasten: An/Aus</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="62"/>
        <source>Solo: On/Off</source>
        <translation>Solo: Ein/Aus</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="63"/>
        <source>Mute: On/Off</source>
        <translation>Stumm: Ein/Aus</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="64"/>
        <source>Arm: On/Off</source>
        <translation>Aufnahme: Ein/Aus</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="65"/>
        <source>Mode: Edit</source>
        <translation>Modus: Bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="66"/>
        <source>Mode: Curve</source>
        <translation>Modus: Kurve</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.cpp" line="458"/>
        <source>Export start frame starts beyond export end frame!!</source>
        <translation>Der erste Frame des Exports liegt hinter dem letzten Frame!!</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.cpp" line="463"/>
        <source>Export tries to render to 0 channels wav file??</source>
        <translation>Es soll eine WAVE-Datei mit 0 Kanälen geschrieben werden??</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.cpp" line="454"/>
        <source>No audio to export! (Is everything muted?)</source>
        <translation>Keine Audiodaten zu exportieren! (Sind alle Kanäle stumm geschalten?)</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.cpp" line="1188"/>
        <source>No Tracks armed for recording!</source>
        <translation>Keine Spur auf Aufnahme gestellt!</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="67"/>
        <source>To previous snap position</source>
        <translation>Zur vorherigen Rasterposition</translation>
    </message>
    <message>
        <location filename="../../src/core/Sheet.h" line="68"/>
        <source>To next snap position</source>
        <translation>Zur nächsten Raster-Position</translation>
    </message>
</context>
<context>
    <name>SheetView</name>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="45"/>
        <source>Center View</source>
        <translation>Center Ansicht</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="46"/>
        <source>Right</source>
        <translation>Rechts</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="47"/>
        <source>Left</source>
        <translation>Links</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="48"/>
        <source>Up</source>
        <translation>Hoch</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="49"/>
        <source>Down</source>
        <translation>Runter</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="50"/>
        <source>Shuttle</source>
        <translation>Shuttle</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="51"/>
        <source>To start</source>
        <translation>Zum Start</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="52"/>
        <source>To end</source>
        <translation>Zum Ende</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="56"/>
        <source>Add Marker</source>
        <translation>Marker hinzufügen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="57"/>
        <source>Add Marker at Playhead</source>
        <translation>Wiedergabekopf: zum Arbeitscursor</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="44"/>
        <source>Set</source>
        <translation>Set</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="53"/>
        <source>To Start</source>
        <translation>zum Start</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="55"/>
        <source>Move</source>
        <translation>Bewegen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="58"/>
        <source>To workcursor</source>
        <translation>zum Arbeits-Cursor</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/SheetView.h" line="59"/>
        <source>Center</source>
        <translation>Center</translation>
    </message>
</context>
<context>
    <name>SongInfoWidget</name>
    <message>
        <location filename="../../src/traverso/ui/SheetInfoWidget.ui" line="16"/>
        <source>SongInfoWidget</source>
        <translation>Song-Informationen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetInfoWidget.ui" line="58"/>
        <source>Song</source>
        <translation>Song</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetInfoWidget.ui" line="332"/>
        <source>-</source>
        <translation>-</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetInfoWidget.ui" line="126"/>
        <source>Snap</source>
        <translation>Einrasten</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetInfoWidget.ui" line="186"/>
        <source>Gain</source>
        <translation>Lautstärke</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetInfoWidget.ui" line="229"/>
        <source>SMPTE</source>
        <translation>SMPTE</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SheetInfoWidget.ui" line="300"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
</context>
<context>
    <name>SpectralMeterConfigWidget</name>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="25"/>
        <source>Frequency Range</source>
        <translation>Frequenzbereich</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="37"/>
        <source>Show average spectrum</source>
        <translation>Durchschnitts-Spektrum zeigen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="57"/>
        <source>Number of bands:</source>
        <translation>Anzahl Bänder:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="77"/>
        <source>Lower dB value:</source>
        <translation>Untere dB-Schwelle:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="94"/>
        <source>Upper dB value:</source>
        <translation>Obere dB-Schwelle:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="124"/>
        <source> Hz</source>
        <translation> Hz</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="117"/>
        <source>Lower Limit:</source>
        <translation>Untere Grenze:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="140"/>
        <source>Upper Limit:</source>
        <translation>Obere Grenze:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="150"/>
        <source>Advanced FFT Options</source>
        <translation>Erweiterte FFT Optionen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="162"/>
        <source>FFT Size:</source>
        <translation>FFT Größe:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="173"/>
        <source>256</source>
        <translation>256</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="178"/>
        <source>512</source>
        <translation>512</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="183"/>
        <source>1024</source>
        <translation>1024</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="188"/>
        <source>2048</source>
        <translation>2048</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="193"/>
        <source>4096</source>
        <translation>4096</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="198"/>
        <source>8192</source>
        <translation>8192</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="207"/>
        <source>Rectangle</source>
        <translation>Rechteck</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="212"/>
        <source>Hanning</source>
        <translation>Hanning</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="217"/>
        <source>Hamming</source>
        <translation>Hamming</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="222"/>
        <source>Blackman</source>
        <translation>Blackman</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="230"/>
        <source>Windowing function:</source>
        <translation>Fensterungsfunktion:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="248"/>
        <source>Advanced</source>
        <translation>Erweitert</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="271"/>
        <source>Apply</source>
        <translation>Anwenden</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="281"/>
        <source>&amp;Close</source>
        <translation>S&amp;chließen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SpectralMeterConfigWidget.ui" line="13"/>
        <source>FFT-Spectrum Configuration</source>
        <translation>Konfiguration des FFT-Spektrums</translation>
    </message>
</context>
<context>
    <name>SpectralMeterView</name>
    <message>
        <location filename="../../src/traverso/widgets/SpectralMeterWidget.cpp" line="484"/>
        <source>Screen Capture file name</source>
        <translation>Schnappschuss Dateiname</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/SpectralMeterWidget.cpp" line="492"/>
        <source>FFT: Unable to write captured image to hard disk</source>
        <translation>FFT: Konnte erfasstes Bild nicht auf Festplatte schreiben</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/SpectralMeterWidget.cpp" line="503"/>
        <source>FFT: No avarage curve used, not data to export!</source>
        <translation>FFT: Keine Durschnittskurve verwendet, keine exportfähigen Daten vorhanden!</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/SpectralMeterWidget.cpp" line="504"/>
        <source>FFT: Enable avarage curve with &lt; M &gt; to generate data</source>
        <translation>FFT: Aktivieren Sie die Durchschnittskurve mit &lt; M &gt; um Daten zu erfassen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/SpectralMeterWidget.cpp" line="512"/>
        <source>FFT: No avarage data to export!</source>
        <translation>FFT: Keine Durchschnittswerte für den Export!</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/SpectralMeterWidget.cpp" line="525"/>
        <source>Select output format</source>
        <translation>Ausgabeformat wählen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/SpectralMeterWidget.cpp" line="525"/>
        <source>Output format:</source>
        <translation>Ausgabeformat:</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/SpectralMeterWidget.cpp" line="533"/>
        <source>Export average dB curve</source>
        <translation>Durchschnittliche dB-Kurve exportieren</translation>
    </message>
</context>
<context>
    <name>SplitClip</name>
    <message>
        <location filename="../../src/commands/SplitClip.cpp" line="37"/>
        <source>Split Clip</source>
        <translation>Clip aufteilen</translation>
    </message>
</context>
<context>
    <name>SysInfoToolBar</name>
    <message>
        <location filename="../../src/traverso/widgets/InfoWidgets.cpp" line="416"/>
        <source>System Information</source>
        <translation>Systeminformationen</translation>
    </message>
</context>
<context>
    <name>SystemInfoWidget</name>
    <message>
        <location filename="../../src/traverso/ui/SystemInfoWidget.ui" line="16"/>
        <source>SystemInfoWidget</source>
        <translation>Systeminformationen</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SystemInfoWidget.ui" line="54"/>
        <source>Card Name (na)</source>
        <translation>Soundkarte</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SystemInfoWidget.ui" line="228"/>
        <source>image</source>
        <translation>Bild</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SystemInfoWidget.ui" line="130"/>
        <source>buffer size (na)</source>
        <translation>Puffergrösse</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SystemInfoWidget.ui" line="137"/>
        <source>rate</source>
        <translation>Rate</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SystemInfoWidget.ui" line="161"/>
        <source>- GB</source>
        <translation>- GB</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SystemInfoWidget.ui" line="168"/>
        <source>drivertype (na)</source>
        <translation>Audio-Treiber</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SystemInfoWidget.ui" line="201"/>
        <source>xruns (na)</source>
        <translation>xruns</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SystemInfoWidget.ui" line="208"/>
        <source>latency (na)</source>
        <translation>Latenz</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SystemInfoWidget.ui" line="215"/>
        <source> - %</source>
        <translation>(sp)- %</translation>
    </message>
    <message>
        <location filename="../../src/traverso/ui/SystemInfoWidget.ui" line="235"/>
        <source>bitdepth</source>
        <translation>Bit-Tiefe</translation>
    </message>
</context>
<context>
    <name>SystemResources</name>
    <message>
        <location filename="../../src/traverso/widgets/InfoWidgets.cpp" line="73"/>
        <source>Read Buffer Status</source>
        <translation>Lesepuffer-Status</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/InfoWidgets.cpp" line="74"/>
        <source>Write Buffer Status</source>
        <translation>Schreibpuffer-Status</translation>
    </message>
</context>
<context>
    <name>TimeLine</name>
    <message>
        <location filename="../../src/core/TimeLine.cpp" line="82"/>
        <source>Add Marker</source>
        <translation>Marker hinzufügen</translation>
    </message>
    <message>
        <location filename="../../src/core/TimeLine.cpp" line="99"/>
        <source>Remove Marker</source>
        <translation>Marker entfernen</translation>
    </message>
</context>
<context>
    <name>TimeLineView</name>
    <message>
        <location filename="../../src/sheetcanvas/TimeLineView.cpp" line="347"/>
        <source>End</source>
        <translation>Ende</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TimeLineView.h" line="72"/>
        <source>Add Marker</source>
        <translation>Marker hinzufügen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TimeLineView.h" line="75"/>
        <source>Drag Marker</source>
        <translation>Marker ziehen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TimeLineView.cpp" line="475"/>
        <source>Clear Markers</source>
        <translation>Mehrere Marker löschen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TimeLineView.h" line="74"/>
        <source>Remove Marker</source>
        <translation>Marker entfernen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TimeLineView.h" line="76"/>
        <source>Clear all Markers</source>
        <translation>Alle Marker löschen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TimeLineView.h" line="73"/>
        <source>Add Marker at Playhead</source>
        <translation>Füge Marker beim Wiedergabekopf ein</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TimeLineView.h" line="77"/>
        <source>Playhead to Marker</source>
        <translation>Bewege Wiedergabekopf zum Marker</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TimeLineView.cpp" line="378"/>
        <source>You have to remove all other markers first.</source>
        <translation>Alle Marker müssen erst gelöscht werden.</translation>
    </message>
</context>
<context>
    <name>Track</name>
    <message>
        <location filename="../../src/core/Track.cpp" line="493"/>
        <source>Silence Others</source>
        <translation>Andere stummschalten</translation>
    </message>
    <message>
        <location filename="../../src/core/Track.cpp" line="222"/>
        <source>Remove Clip</source>
        <translation>Clip entfernen</translation>
    </message>
    <message>
        <location filename="../../src/core/Track.cpp" line="236"/>
        <source>Add Clip</source>
        <translation>Clip hinzufügen</translation>
    </message>
    <message>
        <location filename="../../src/core/Track.cpp" line="168"/>
        <source>Track: AudioClip with id %1 not <byte value="x9"/><byte value="x9"/><byte value="x9"/><byte value="x9"/><byte value="x9"/><byte value="x9"/>found in Resources database!</source>
        <translation>Track: AudioClip mit der ID %1 in der Resourcendatenbank nicht gefunden!</translation>
    </message>
    <message>
        <location filename="../../src/core/Track.h" line="45"/>
        <source>Mute</source>
        <translation>Stummschaltung</translation>
    </message>
    <message>
        <location filename="../../src/core/Track.h" line="46"/>
        <source>Record: On/Off</source>
        <translation>Aufnahme: An/Aus</translation>
    </message>
    <message>
        <location filename="../../src/core/Track.h" line="47"/>
        <source>Solo</source>
        <translation>Solo</translation>
    </message>
    <message>
        <location filename="../../src/core/Track.h" line="48"/>
        <source>Silence other tracks</source>
        <translation>Andere Tracks stummschalten</translation>
    </message>
</context>
<context>
    <name>TrackPan</name>
    <message>
        <location filename="../../src/commands/TrackPan.cpp" line="52"/>
        <source>Track Pan: %1</source>
        <translation>Track Balance: %1</translation>
    </message>
    <message>
        <location filename="../../src/commands/TrackPan.cpp" line="55"/>
        <source>Track Pan</source>
        <translation>Track Balance</translation>
    </message>
</context>
<context>
    <name>TrackView</name>
    <message>
        <location filename="../../src/sheetcanvas/TrackView.cpp" line="153"/>
        <source>Set Track name</source>
        <translation>Track-Name</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TrackView.cpp" line="154"/>
        <source>Enter new Track name</source>
        <translation>Geben Sie einen neuen Track-Namen ein</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TrackView.cpp" line="166"/>
        <source>Track %1:  %2</source>
        <translation>Track %1:  %2</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TrackView.h" line="36"/>
        <source>Edit properties</source>
        <translation>Eigenschaften bearbeiten</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TrackView.h" line="37"/>
        <source>Add new Plugin</source>
        <translation>Neues Plugin hinzufügen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TrackView.h" line="38"/>
        <source>Select Bus</source>
        <translation>Bus wählen</translation>
    </message>
    <message>
        <location filename="../../src/sheetcanvas/TrackView.h" line="39"/>
        <source>Insert Silence</source>
        <translation>Stille einfügen</translation>
    </message>
</context>
<context>
    <name>TransportConsoleWidget</name>
    <message>
        <location filename="../../src/traverso/widgets/TransportConsoleWidget.cpp" line="60"/>
        <source>Skip to Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/TransportConsoleWidget.cpp" line="61"/>
        <source>Previous Snap Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/TransportConsoleWidget.cpp" line="62"/>
        <source>Record</source>
        <translation>Aufnahme</translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/TransportConsoleWidget.cpp" line="63"/>
        <source>Play / Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/TransportConsoleWidget.cpp" line="64"/>
        <source>Next Snap Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/TransportConsoleWidget.cpp" line="65"/>
        <source>Skip to End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/traverso/widgets/TransportConsoleWidget.cpp" line="184"/>
        <source>Recording to %1 Tracks, encoding format: %2</source>
        <translation>Aufnahme in %1 Spuren, Kodierung: %2</translation>
    </message>
</context>
<context>
    <name>TraversoCommands</name>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="31"/>
        <source>Gain</source>
        <translation>Gain</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="32"/>
        <source>Gain: Reset</source>
        <translation>Gain: Zurücksetzen</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="33"/>
        <source>Panorama</source>
        <translation>Panorama</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="34"/>
        <source>Panorama: Reset</source>
        <translation>Panorama: Zurücksetzen</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="35"/>
        <source>Import Audio</source>
        <translation>Audio importieren</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="36"/>
        <source>Insert Silence</source>
        <translation>Stille einfügen</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="37"/>
        <source>Copy Clip</source>
        <translation>Clip kopieren</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="38"/>
        <source>New Track</source>
        <translation>Neuer Track</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="39"/>
        <source>Remove Clip</source>
        <translation>Clip entfernen</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="40"/>
        <source>Remove Track</source>
        <translation>Track entfernen</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="41"/>
        <source>External Processing</source>
        <translation>Externe Verarbeitung</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="44"/>
        <source>Move Clip</source>
        <translation>Clip verschieben</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="45"/>
        <source>Drag Edge</source>
        <translation>Kante ziehen</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="46"/>
        <source>Move Or Resize Clip</source>
        <translation>Clip verschieben oder Größe ändern</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="47"/>
        <source>Split</source>
        <translation>Aufteilen</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="49"/>
        <source>Arm Tracks</source>
        <translation>Tracks auf Aufnahme schalten</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="50"/>
        <source>Fold Sheet</source>
        <translation>Arbeitsbereich falten</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="51"/>
        <source>Fold Track</source>
        <translation>Spur falten</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="53"/>
        <source>Vertical In</source>
        <translation>Vertikal rein</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="54"/>
        <source>Horizontal Out</source>
        <translation>Horizontal raus</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="55"/>
        <source>Horizontal In</source>
        <translation>Horizontal rein</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="56"/>
        <source>Vertical Out</source>
        <translation>Vertikal raus</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="57"/>
        <source>Omnidirectional</source>
        <translation>Omnidirektional</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="58"/>
        <source>Horizontal</source>
        <translation>Horizontal</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="59"/>
        <source>Vertical</source>
        <translation>Vertikal</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="60"/>
        <source>Right</source>
        <translation>Rechts</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="61"/>
        <source>Left</source>
        <translation>Links</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="62"/>
        <source>Up</source>
        <translation>Hoch</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="63"/>
        <source>Down</source>
        <translation>Runter</translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="43"/>
        <source>(De)Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="52"/>
        <source>Fold Markers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="42"/>
        <source>(De)Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/commands/plugins/TraversoCommands/TraversoCommands.h" line="48"/>
        <source>Magnetic Cut</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
