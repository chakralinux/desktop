.. _index:

:mod:`parched`
==============

.. automodule:: parched
.. autoclass:: Package
    :members:

.. autoclass:: PacmanPackage
   :members:

.. autoclass:: PKGBUILD
   :members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
